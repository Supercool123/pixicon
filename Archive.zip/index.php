<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Sassy Salon Services</title>

<!-- Google fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>

<!-- font awesome -->
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">

<!-- bootstrap -->
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />

<!-- animate.css -->
<link rel="stylesheet" href="assets/animate/animate.css" />
<link rel="stylesheet" href="assets/animate/set.css" />

<!-- gallery -->
<link rel="stylesheet" href="assets/gallery/blueimp-gallery.min.css">

<!-- favicon -->
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">


<link rel="stylesheet" href="assets/style.css">
<style type="text/css">
  .table-striped > tbody > tr:nth-child(2n+1) > td, .table-striped > tbody > tr:nth-child(2n+1) > th {
   background-color: #ff6699;} 
   .sep{
    max-width: 100px;
    border: 2px solid #ff6699;
    
    margin-bottom: 40px;
   }
   #i{
    border: 2px solid #fff;
   }
 .bton {
  border-radius: 5px;
  padding: 15px 25px;
  font-size: 22px;
  text-decoration: none;
  margin: 20px;
  color: #fff;
  position: relative;
  display: inline-block;
}

.bton:active {
  transform: translate(0px, 5px);
  -webkit-transform: translate(0px, 5px);
  box-shadow: 0px 1px 0px 0px;
}
.yellow {
  background-color: #ff2483;
  box-shadow: 0px 5px 0px 0px #ff8899;
}

.yellow:hover {
  background-color: #ff6699;
  color:#FFF;
}
.modal-open .modal {
  overflow-x: hidden;
  overflow-y: auto;
}
</style>
<link rel="stylesheet" type="text/css" href="assets/table/css/main.css">
<link rel="stylesheet" type="text/css" href="assets/table/css/style.css">
<link rel="stylesheet" type="text/css" href="assets/Form/formcss.css">

</head>

<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>



<div class="topbar animated fadeInLeftBig"></div>

<!-- Header Starts -->
<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation" id="top-nav">
          <div class="container">
            <div class="navbar-header">
              <!-- Logo Starts -->
              <a class="navbar-brand" href="#home"><img src="images/pink.png" alt="logo"></a>
              <!-- #Logo Ends -->


              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right scroll">
                 <li class="active"><a href="#home">Home</a></li>
                 <li ><a href="#works">Services</a></li>
                 <li ><a href="#offers">Offers</a></li>
                 <li ><a href="#packages">Packages</a></li>
                 <li ><a href="#partners">Testimonials</a></li>
                 <li ><a href="#about">Why Sassy?</a></li>
                 <li ><a href="#contact">Contact</a></li>
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>
<!-- #Header Starts -->




<div id="home">
<!-- Slider Starts -->
<div id="myCarousel" class="carousel slide banner-slider animated bounceInDown" data-ride="carousel" style="height:100%">     
      <div class="carousel-inner">
        <!-- Item 1 -->
        <div class="item active">
          <img src="images/back1.jpg" alt="banner">
          <div class="carousel-caption" style="padding-bottom:5%;padding-right:45%">
          <a class="bton yellow" data-toggle="modal" data-target="#form" style="text-decoration:none;cursor: pointer;">Book Now</a>         </div>
        </div>
        <!-- #Item 1 -->

        <!-- Item 1 -->
        <div class="item">
          <img src="images/back2.jpg" alt="banner">
                    <div class="carousel-caption" style="padding-bottom:5%;padding-right:45%">
           <a class="bton yellow" data-toggle="modal" data-target="#form" style="text-decoration:none;cursor: pointer;">Book Now</a>
          </div>
        </div>
        <!-- #Item 1 -->

        <!-- Item 1 -->
        <div class="item">
          <img src="images/back3.jpg" alt="banner">
                    <div class="carousel-caption" style="padding-bottom:5%;padding-right:45%">
          <a class="bton yellow" data-toggle="modal" data-target="#form" style="text-decoration:none;cursor: pointer;">Book Now</a>
          </div>
        </div>
        <!-- #Item 1 -->

        <!-- Item 1 -->
        <div class="item">
          <img src="images/back4.jpg" alt="banner">
                    <div class="carousel-caption" style="padding-bottom:5%;padding-right:45%">
           <a class="bton yellow" data-toggle="modal" data-target="#form" style="text-decoration:none;cursor: pointer;">Book Now</a>
          </div>
        </div>
        <!-- #Item 1 -->
      </div>
      <a class="left carousel-control" href="#myCarousel" data-slide="prev"><span class="icon-prev"></span></a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next"><span class="icon-next"></span></a>
    </div>
<!-- #Slider Ends -->
</div>









  

<!-- works -->

  <div class="container" style="padding-top:5%"><center><h2 >Services</h2></center>
   <center><hr class="sep"></center></div>
   <div  class=" clearfix grid" id="works"> 
   
    <figure  class="effect-oscar  wowload fadeInUp">
        <img src="images/portfolio/1.jpg" alt="img01"/>
        <figcaption>
            <h2 style="color:#ff6699;">Hair</h2>
            <p> "We truly believe, Haircut matters"<br>
            <a   data-toggle="modal" data-target="#form">Book Now</a>&nbsp;<a  data-toggle="modal" data-target="#myModal1">View more</a></p>            
        </figcaption>
    </figure>
     <figure class="effect-oscar  wowload fadeInUp">
        <img src="images/portfolio/2.jpg" alt="img01"/>
        <figcaption>
            <h2 style="color:#ff6699;">Facial</h2>
            <p>"Take a deep breath and enjoy your facial"<br>
            <a  data-toggle="modal" data-target="#form">BookNow</a>&nbsp;<a  data-toggle="modal" data-target="#2">View more</a></p> 
        </figcaption>
    </figure>
     <figure class="effect-oscar  wowload fadeInUp">
        <img src="images/portfolio/3.jpg" alt="img01"/>
        <figcaption>
            <h2 style="color:#ff6699;">Massage</h2>
            <p>"The best time to Relax, is when there is no time"<br>
            <a  data-toggle="modal" data-target="#form">Book Now</a>&nbsp;<a  data-toggle="modal" data-target="#myModal3">View more</a></p>         
        </figcaption>
    </figure>
     <figure class="effect-oscar  wowload fadeInUp">
        <img src="images/portfolio/4.jpg" alt="img01"/>
        <figcaption>
            <h2 style="color:#ff6699;">Waxing</h2>
            <p>"waxing is not a luxury it's a necessity"<br>
            <a  data-toggle="modal" data-target="#form">Book Now</a>&nbsp;<a  data-toggle="modal" data-target="#myModal4">View more</a></p>            
        </figcaption>
    </figure>
     <figure class="effect-oscar  wowload fadeInUp">
        <img src="images/portfolio/5.jpg" alt="img01"/>
        <figcaption>
            <h2 style="color:#ff6699;">Nail</h2>
            <p>"THe happiest girls always have the prettiest nails"<br>
            <a  data-toggle="modal" data-target="#form">Book Now</a>&nbsp;<a  data-toggle="modal" data-target="#myModal5">View more</a></p>            
        </figcaption>
    </figure>
     
     <figure class="effect-oscar  wowload fadeInUp">
        <img src="images/portfolio/6.jpg" alt="img01"/>
        <figcaption>
            <h2 style="color:#ff6699;">Makeup</h2>
            <p>"Make up is an art and sassy is the artist"<br>
            <a  data-toggle="modal" data-target="#form">Book Now</a>&nbsp;<a  data-toggle="modal" data-target="#myModal6">View more</a></p>            
        </figcaption>
    </figure>
    
</div>

<!-- works -->


<div class="container" id="offers">
<?php include 'view_offers.php'; ?>
</div>
</div>


<div class="container" id="packages">
<?php include 'test_table.php'; ?>
</div>
</div>





<div id="partners" class="container spacer " style="padding-bottom:10%">
	<center><h2 class=" wowload fadeInUp" style="color:#ff6699;font-weight:bold">Testimonials</h2></center>
  <center><hr class="sep"></center>
  <div class="clearfix">
    
    <div class="container">


    <div id="carousel-testimonials" class="carousel slide testimonails  wowload fadeInRight" data-ride="carousel">
    <div class="carousel-inner">  
      <div class="item active animated bounceInRight row">
      <div class="animated slideInLeft col-xs-2"><img alt="portfolio" src="images/team/1.jpg" width="100" class="img-circle img-responsive"></div>
      <div  class="col-xs-10">
      <p style="color:#ff6699;">Sassy helped me in REDEFINING MYSELF... It helped me in putting forward my true self. </p>       
      <span><b>Pooja Shrivastava</b>--- Mate Square</span>
      </div>
      </div>
      <div class="item  animated bounceInRight row">
      <div class="animated slideInLeft col-xs-2"><img alt="portfolio" src="images/team/2.jpg" width="100" class="img-circle img-responsive"></div>
      <div  class="col-xs-10">
      <p style="color:#ff6699;">Great Service,so friendly and Pretty much pain free. Best waxing experience. Had very relaxing yet professional facial...that too straight at  our home.</p>
      <span><b>Juhi Kotwal-Pradhan</b>--- Somalwada</span>
      </div>
      </div>
      <div class="item  animated bounceInRight row">
      <div class="animated slideInLeft  col-xs-2"><img alt="portfolio" src="images/team/3.jpg" width="100" class="img-circle img-responsive"></div>
      <div  class="col-xs-10">
      <p style="color:#ff6699;">Had the most amazing experience with Sassy Salon. Relaxing, rejuvenating and effective that too all in the comfort of my own home.</p>
      <span ><b>Rijuta Joshi</b>--- Bajaj Nagar</span>
      </div>
      </div>
      <div class="item  animated bounceInRight row">
      <div class="animated slideInLeft  col-xs-2"><img alt="portfolio" src="images/team/4.jpg" width="100" class="img-circle img-responsive"></div>
      <div  class="col-xs-10">
      <p style="color:#ff6699;">I am extremely happy with the home services offered by Sassy. They are very punctual, hygienic and value for money. I have recommended the services to many of my friends, All the Best.</p>
      <span ><b>Minakshi Randive</b>--- Manewada</span>
      </div>
      </div>
  </div>

   <!-- Indicators -->
   	<ol class="carousel-indicators">
    <li data-target="#carousel-testimonials" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-testimonials" data-slide-to="1"></li>
    <li data-target="#carousel-testimonials" data-slide-to="2"></li>
    <li data-target="#carousel-testimonials" data-slide-to="3"></li>
  	</ol>
  	<!-- Indicators -->
  </div>
</div>
</div>
</div>


    </div>
  </div>







</div>


<!--about starts-->
<div class="highlight-info" id="about">
<div class="overlay spacer">
<div class="container">
<center><h2  style="font-weight:bold;color:#fff;">Why Sassy?</h2></center><br>
<center><hr class="sep" id="i"></center>
<div class="row text-center  wowload fadeInDownBig">
  <div class="col-sm-3 col-xs-6">
  <img src="images/products.png"><h4 style="font-weight:bold;">Best Products</h4><br>
  <h5 style="font-weight:bold;color:#fff">Our preferences are alot like yours, Quality First!</h5>
  </div>
  <div class="col-sm-3 col-xs-6">
  <img src="images/train.png"><h4 style="font-weight:bold;">Trained Beauticians</h4><br>
  <h5 style="font-weight:bold;color:#fff">Our employees mostly have first hand experience for better understanding of customer needs.</h5>
  </div>
  <div class="col-sm-3 col-xs-6">
  <img src="images/check.png"><h4 style="font-weight:bold;">Verified Background</h4><br>
  <h5 style="font-weight:bold;color:#fff">We are concerned for your safety, every employee is verified.</h5>
  </div>
 <div class="col-sm-3 col-xs-6">
  <img src="images/satisfaction.png"><h4 style="font-weight:bold;">Customer Satisfaction</h4><br>
  <h5 style="font-weight:bold;color:#fff">Our Ambition is Your Satisfaction.</h5>
  </div>
</div>
</div>
</div>
</div>

<!--about ends-->







<div id="contact" class="spacer">
<div class="container">
<div class="col-lg-4 col-md-4 col-xs-12 col-sm-4">
  <blockquote class="instagram-media" data-instgrm-captioned data-instgrm-version="7" style=" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:658px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);"><div style="padding:8px;"> <div style=" background:#F8F8F8; line-height:0; margin-top:40px; padding:50.0% 0; text-align:center; width:100%;"> <div style=" background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAMAAAApWqozAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAMUExURczMzPf399fX1+bm5mzY9AMAAADiSURBVDjLvZXbEsMgCES5/P8/t9FuRVCRmU73JWlzosgSIIZURCjo/ad+EQJJB4Hv8BFt+IDpQoCx1wjOSBFhh2XssxEIYn3ulI/6MNReE07UIWJEv8UEOWDS88LY97kqyTliJKKtuYBbruAyVh5wOHiXmpi5we58Ek028czwyuQdLKPG1Bkb4NnM+VeAnfHqn1k4+GPT6uGQcvu2h2OVuIf/gWUFyy8OWEpdyZSa3aVCqpVoVvzZZ2VTnn2wU8qzVjDDetO90GSy9mVLqtgYSy231MxrY6I2gGqjrTY0L8fxCxfCBbhWrsYYAAAAAElFTkSuQmCC); display:block; height:44px; margin:0 auto -44px; position:relative; top:-22px; width:44px;"></div></div> <p style=" margin:8px 0 0 0; padding:0 4px;"> <a href="https://www.instagram.com/p/BHwnkn_BCVx/" style=" color:#000; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px; text-decoration:none; word-wrap:break-word;" target="_blank">Sassy&#39;s first event@ Lata Mangeshkar Hospital #Hingna#Nagpur  #Beauty services at home, delivered by Professional Beauticians in an affordable &amp; hygienic way within 1 hour of request.  call us:- +91-9130936340</a></p> <p style=" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; line-height:17px; margin-bottom:0; margin-top:8px; overflow:hidden; padding:8px 0 7px; text-align:center; text-overflow:ellipsis; white-space:nowrap;">A photo posted by Sassy Salon (@sassy.salon) on <time style=" font-family:Arial,sans-serif; font-size:14px; line-height:17px;" datetime="2016-07-12T11:25:20+00:00">Jul 12, 2016 at 4:25am PDT</time></p></div></blockquote>
<script async defer src="//platform.instagram.com/en_US/embeds.js"></script>
</div>
<div class="col-lg-4 col-xs-12 col-sm-4 col-md-4">
<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Need waxing?Your home, your time!<br>Sassy Home Services.Call Now: +91-9130936340<a href="https://t.co/lADanmf19O">https://t.co/lADanmf19O</a> <a href="https://t.co/jqCvkvnl7z">pic.twitter.com/jqCvkvnl7z</a></p>&mdash; Sassy Salon (@salon_sassy) <a href="https://twitter.com/salon_sassy/status/761578127847854081">August 5, 2016</a></blockquote>
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
</div>
<div class="col-lg-4 col-xs-12 col-sm-4 col-md-4">
 <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FSassy-1623316271252871%2F%3Ffref%3Dts%23&tabs=timeline&width=350&height=500&small_header=false&&hide_cover=false&show_facepile=true&appId"  style="overflow:hidden;height:500px;width:100%" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
</div>
</div>
</div>
</div>
<!--Contact Ends-->



<!-- Footer Starts -->
<div class="footer text-center spacer">
<div class="container">
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
  <form id="contact" action="" method="post" style="background:transparent">
    
    <h4>Anything You Might Want To Say</h4>
    <fieldset>
      <input placeholder="Your name" type="text" tabindex="1"  >
    </fieldset>
    <fieldset>
      <input placeholder="Your Email Address" type="email" tabindex="2" >
    </fieldset>
    <fieldset>
      <input placeholder="Your Phone Number (optional)" type="tel" tabindex="3" >
    </fieldset>
    
    <fieldset>
     <textarea placeholder="Type your message here...." tabindex="5" ></textarea>
    </fieldset>
    <fieldset>
      <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Submit</button><br>
      
    </fieldset> 
</form>
</div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<br><br><br>
<p class="wowload flipInX"><a href="https://www.facebook.com/Sassy-1623316271252871/?fref=ts"><i class="fa fa-facebook fa-2x" style="color:#ff6699;"></i></a> <a href="https://www.instagram.com/sassy.salon/"><i class="fa fa-instagram fa-2x" style="color:#ff6699;"></i></a> <a href="https://twitter.com/salon_sassy"><i class="fa fa-twitter fa-2x" style="color:#ff6699;"></i></a>   </p>

  
   
      <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12" style="padding:1%;cursor: pointer; "><a data-target="#privacy" data-toggle="modal">Privacy & Policy</a></div>
      <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12" style="padding:1%;cursor: pointer; "><a data-target="#terms" data-toggle="modal">Terms & Conditions</a></div>
      <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12" style="padding:1%;cursor: pointer; "><a data-target="#aboutus" data-toggle="modal">About Us</a></div>
        
      <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12" style="padding:1%;cursor: pointer; "><a href="contactus.html">Contact Us</a></div>
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:1%;cursor: pointer; "><a data-target="#faq" data-toggle="modal">FAQ</a></div>

For Whatsapp Booking Just Send Your Name & Number To: <br><br>
<i class="fa fa-whatsapp" style="font-size:32px; color:#ff6699;"></i>+91-9850690802<br><br>
&copy;Copyright 2016 Sassy Salon Services. All rights reserved.
</div>
</div>
</div>

<!-- # Footer Ends -->


<a href="#home" class="gototop "><i class="fa fa-angle-up  fa-3x" style="color:#ff8899;"></i></a>









<!-- Modal -->
  <div class="modal fade" id="form" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        
        <div class="modal-body">
         <div class="Rahul">  
  <form id="contact" action="" method="post">
    
    <h4>One Step Towards Sassiness.</h4>
    <fieldset>
      <input placeholder="Your name" type="text" tabindex="1"  autofocus>
    </fieldset>
    <fieldset>
      <input placeholder="Your Email Address(optional)" type="email" tabindex="2" >
    </fieldset>
    <fieldset>
      <input placeholder="Your Phone Number " type="tel" tabindex="3" >
    </fieldset>
    <fieldset>
      <input placeholder="Your Address (optional)" type="text"  tabindex="4" >
    </fieldset>
    <fieldset>
     <label>Time  :  24 hour format</label> <input placeholder="TIME" type="time" name="" maxlength="2" size="2" >
    </fieldset>
    <fieldset>
      <label>Date :</label><input type="date" name="" maxlength="2" size="2" >
    </fieldset>
    <fieldset>
      <textarea placeholder="Type your message here...." tabindex="5" ></textarea>
    </fieldset>
    <fieldset>
      <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Submit</button><br>
      <h6>Kindly Book An Appointment 2 Hours Before Required Time</h6>
    </fieldset> 
  
  </form>
</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<?php include 'privacy.php'; ?>
<?php include 'terms.php'; ?>
<?php include 'aboutus.php';?>
<?php include 'faqs.php'; ?>
    
<!-- jquery -->
<script src="assets/jquery.js"></script>

<!-- wow script -->
<script src="assets/wow/wow.min.js"></script>


<!-- boostrap -->
<script src="assets/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="assets/mobile/touchSwipe.min.js"></script>
<script src="assets/respond/respond.js"></script>

<!-- gallery -->
<script src="assets/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="assets/script.js"></script>
<!-- Modal -->
  <div class="modal fade" id="myModal5" role="dialog">
    <div class="modal-dialog">
    




      <!-- Modal content-->
      <div class="modal-content" style="background-color:rgba(94,94,94,0.83);">
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
           <center><h2  style="font-weight: bold;color:#fff;background-color:#ff6699;" >NAILS</h2></center>
        </div>
        <div class="modal-body">
          <?php include 'test_nails_rate.php'; ?>
        </div>
        <div class="modal-footer">
         <h6 style="color:#fff"> * Inclusive of all taxes and charges. | For Women Only</h6>
         <button type="button" class="btn btn-default" data-toggle="modal" data-target="#form2">Book Now</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


 <!-- Modal -->
  <div class="modal fade" id="myModal4" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color:rgba(94,94,94,0.83);">
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
          <center><h2  style="font-weight: bold;color:#fff;background-color:#ff6699;" >WAXING</h2></center>
        </div>
        <div class="modal-body">
           <?php include'test_waxing_rate.php'; ?>
        </div>
        <div class="modal-footer">
         <h6 style="color:#fff"> * Inclusive of all taxes and charges. | For Women Only</h6>
         <button type="button" class="btn btn-default" data-toggle="modal" data-target="#form2">Book Now</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  





<!-- Modal -->
  <div class="modal fade" id="2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color:rgba(94,94,94,0.83);">
        <div class="modal-header">

          <a type="button" class="close" data-dismiss="modal" style="padding-left:1%;padding-right:1%">&times;</a>
          <center><h2  style="font-weight: bold;color:#fff;background-color:#ff6699;" >FACIAL</h2></center>
           </div>
        <div class="modal-body">
          <?php include 'test_facial_rate.php'; ?>
       
        <div class="modal-footer">

       <h6 style="color:#fff"> * Inclusive of all taxes and charges. | For Women Only</h6>
   		<button type="button" class="btn btn-default" data-toggle="modal" data-target="#form2">Book Now</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      </div>
      
    </div>
  </div>





 <!-- Modal -->
  <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color:rgba(94,94,94,0.83);">
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
           <center><h2  style="font-weight: bold;color:#fff;background-color:#ff6699;">MASSAGE</h2></center>
        </div>
        <div class="modal-body">
          <?php include 'test_massage_rate.php'; ?>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default" data-toggle="modal" data-target="#form2">Book Now</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  




  

 <!-- Modal -->
  <div class="modal fade" id="myModal6" role="dialog">
    <div class="modal-dialog ">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color:rgba(94,94,94,0.83);">
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
           <center><h2  style="font-weight: bold;color:#fff;background-color:#ff6699;" >MAKE UP</h2></center>
        </div>
        <div class="modal-body">
          <?php include 'test_makeup.php' ?>
        </div>
        <div class="modal-footer">
         <h6 style="color:#fff"> * Inclusive of all taxes and charges. | For Women Only</h6>
         <button type="button" class="btn btn-default" data-toggle="modal" data-target="#form2">Book Now</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>



<!-- Modal -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog ">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color:rgba(94,94,94,0.83);">
      
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
           <center><h2  style="font-weight: bold;color:#fff;background-color:#ff6699;" >HAIR</h2></center>
        </div>
        <div class="modal-body">
        
           <?php include 'test_rate_card.php';  ?>
  
       
        <div class="modal-footer">
         <h6 style="color:#fff"> * Inclusive of all taxes and charges. | For Women Only</h6>
          <button type="button" class="btn btn-default" data-toggle="modal" data-target="#form2">Book Now</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>

    </div>
  </div>
 </div> 


</div>
<?php include 'form2.php';?>
</body>
</html>