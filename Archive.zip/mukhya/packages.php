<?php
include('db_config.php');
// include('connection.php');
New Database();
print_r($_POST);
$packages_name = $_POST['packages_name'];
$packages_price = $_POST['packages_price'];
$packages_item1=$_POST['packages_item1'];
$packages_item2=$_POST['packages_item2'];
$packages_item3=$_POST['packages_item3'];
$packages_item4=$_POST['packages_item4'];
$packages_item5=$_POST['packages_item5'];
$packages_item6=$_POST['packages_item6'];
$packages_item7=$_POST['packages_item7'];
$packages_item8=$_POST['packages_item8'];
$packages_item9=$_POST['packages_item9'];
/*Query to insert packages details in Database*/
$insert_packages_details = 'INSERT INTO price_details(`packages_name`, `packages_price`,`packages_item1`,`packages_item2`,`packages_item3`,`packages_item4`,`packages_item5`,`packages_item6`,`packages_item7`,`packages_item8`,`packages_item9`) VALUES ("'.$packages_name.'", "'.$packages_price.'","'.$packages_item1.'","'.$packages_item2.'","'.$packages_item3.'","'.$packages_item4.'","'.$packages_item5.'","'.$packages_item6.'","'.$packages_item7.'","'.$packages_item8.'","'.$packages_item9.'") ';
// echo $insert_packages_details;
$inserted = mysql_query($insert_packages_details);
header('Location:Package_table.html');
/*$test = "SELECT * FROM ";
$fetch_data  = mysql_query($test) or die(mysql_error());
while($row = mysql_fetch_array($fetch_data)){
echo $row['packages_name'];
}*/
?>