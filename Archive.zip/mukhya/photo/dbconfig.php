<?php
$dbhost = "mysql.2freehosting.com";
$dbuser = "u161389876_data1";
$dbpass = "sassy123";
$dbname = "u161389876_data1";
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');
?>