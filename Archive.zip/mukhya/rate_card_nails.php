<?php
include('db_config.php');
// include('connection.php');
New Database();
print_r($_POST);
$rate_nail_item1 = $_POST['rate_nail_item1'];
$rate_nail_item2 = $_POST['rate_nail_item2'];
$rate_nail_item3 = $_POST['rate_nail_item3'];
$rate_nail_item4 = $_POST['rate_nail_item4'];
$rate_nail_item5 = $_POST['rate_nail_item5'];
$rate_nail_item6 = $_POST['rate_nail_item6'];
$rate_nail_item7 = $_POST['rate_nail_item7'];

/*Query to insert packages details in Database*/
$insert_rate_details = 'INSERT INTO rate_nails(`rate_nail_item1`,`rate_nail_item2`,`rate_nail_item3`,`rate_nail_item4`,`rate_nail_item5`,`rate_nail_item6`,`rate_nail_item7`) VALUES ("'.$rate_nail_item1.'","'.$rate_nail_item2.'","'.$rate_nail_item3.'","'.$rate_nail_item4.'","'.$rate_nail_item5.'","'.$rate_nail_item6.'","'.$rate_nail_item7.'") ';
// echo $insert_packages_details;
$inserted = mysql_query($insert_rate_details);
header('Location:rate_card2.html');
/*$test = "SELECT * FROM ";
$fetch_data  = mysql_query($test) or die(mysql_error());
while($row = mysql_fetch_array($fetch_data)){
echo $row['packages_name'];
}*/
?>