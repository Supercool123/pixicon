<?php
include('db_config.php');
new Database();
$test = "SELECT * FROM rate_facial order by 1  DESC  LIMIT 0,1";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>


<table class="table table-striped" style="font-weight: bold;">
          <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12 col-centered">
    <thead>
      <tr>
        <th style="background-color:#000000;color:#fff"><h4>Facial</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Regular Clean up</td>
        <?php while($row = mysql_fetch_array($fetch_data)):?>
        <td>&#8377;<?php echo $row['rate_facial_item1'];?></td>
       
      </tr>
      <tr>
        <td>Insta Clean Up</td>
        <td>&#8377;<?php echo $row['rate_facial_item2'];?></td>
       
      </tr>
      <tr>
        <td>Herbal Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item3'];?></td>
      </tr>
      <tr>
        <td>Vlcc Fruit Facial</td>
       <td>&#8377;<?php echo $row['rate_facial_item4'];?></td>
        
      </tr>
      <tr>
        <td>Vlcc Silver Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item5'];?></td>
      </tr>
      <tr>
        <td>Vlcc Insta Glow Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item6'];?></td>
      </tr>
      <tr>
        <td>Vlcc Skin Tightening Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item7'];?></td>
      </tr>
      <tr>
        <td>Vlcc Gold Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item8'];?></td>
      </tr>
      <tr>
        <td>Vlcc Party Glow Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item9'];?></td>
      </tr>
      <tr>
        <td>Vlcc Perl Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item10'];?></td>
      </tr>
        <tr>
        <td>Vlcc Diamond Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item11'];?></td>
      </tr>
            <tr>
        <td>Vlcc Anti Tan Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item12'];?></td>
      </tr>
            <tr>
        <td>Cheryl's GloVite Facial (Fairness)</td>
        <td>&#8377;<?php echo $row['rate_facial_item13'];?></td>
      </tr>
            <tr>
        <td>Cheryl's TanClear Facial (Anti Pigmentation)</td>
        <td>&#8377;<?php echo $row['rate_facial_item14'];?></td>
      </tr>
      <tr>
        <td>Cheryl's OxyBlast Facial (Rediance)</td>
        <td>&#8377;<?php echo $row['rate_facial_item15'];?></td>
      </tr>
      
      <tr>
        <td>Cheryl's VitaLift Facial (Anti Ageing)</td>
        <td>&#8377;<?php echo $row['rate_facial_item16'];?></td>
      </tr>
      <tr>
        <td>Cheryl's SensiGlow Facial (Sensitive Skin)</td>
        <td>&#8377;<?php echo $row['rate_facial_item17'];?></td>
      </tr>
      <tr>
        <td>Cheryl's ClariGlow Facial (Oily Skin)</td>
        <td>&#8377;<?php echo $row['rate_facial_item18'];?></td>
      </tr>
      <tr>
        <td>Cheryl's O2C2 Facial (Rediance)</td>
        <td>&#8377;<?php echo $row['rate_facial_item19'];?></td>
      </tr>
      <tr>
        <td>Cheryl's Hydramoist Facial </td>
        <td>&#8377;<?php echo $row['rate_facial_item20'];?></td>
      </tr>
       
<th style="background-color:#000000;color:#fff"><h4>Bleach</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>

        <tr>
        <td>Upper Lip</td>
        <td>&#8377;<?php echo $row['rate_facial_item21'];?></td>
      </tr>
      <tr>
        <td>Chin</td>
        <td>&#8377;<?php echo $row['rate_facial_item22'];?></td>
      </tr>
      <tr>
        <td>Face & Neck</td>
        <td>&#8377;<?php echo $row['rate_facial_item23'];?></td>
      </tr>
      <tr>
        <td>Face, Neck & Blouse Line</td>
        <td>&#8377;<?php echo $row['rate_facial_item24'];?></td>
      </tr>
      <tr>
        <td>Under Arms</td>
        <td>&#8377;<?php echo $row['rate_facial_item25'];?></td>
      </tr>
      <tr>
        <td>Full Hands</td>
        <td>&#8377;<?php echo $row['rate_facial_item26'];?></td>
      </tr>
      <tr>
        <td>Full Legs</td>
        <td>&#8377;<?php echo $row['rate_facial_item27'];?></td>
      </tr>
      <tr>
        <td>Full Back</td>
        <td>&#8377;<?php echo $row['rate_facial_item28'];?></td>
      </tr>
      <tr>
        <td>Full Front</td>
        <td>&#8377;<?php echo $row['rate_facial_item29'];?></td>
      </tr>
      <tr>
        <td>Full Body</td>
        <td>&#8377;<?php echo $row['rate_facial_item30'];?></td>
      </tr>

      
      <th style="background-color:#000000;color:#fff"><h4>Bleach</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      <tr>
        <td>Forehead</td>
        <td>&#8377;<?php echo $row['rate_facial_item31'];?></td>
      </tr>
      <tr>
        <td>Eyebrows</td>
        <td>&#8377;<?php echo $row['rate_facial_item32'];?></td>
      </tr>
      <tr>
        <td>Upper Lip</td>
        <td>&#8377;<?php echo $row['rate_facial_item33'];?></td>
      </tr>
      <tr>
        <td>Lower Lip</td>
        <td>&#8377;<?php echo $row['rate_facial_item34'];?></td>
      </tr>
      <tr>
        <td>Chin</td>
        <td>&#8377;<?php echo $row['rate_facial_item35'];?></td>
      </tr>
      <tr>
        <td>Sides & Jaw Line</td>
        <td>&#8377;<?php echo $row['rate_facial_item36'];?></td>
      </tr>
      <tr>
        <td>Full Face</td>
        <td>&#8377;<?php echo $row['rate_facial_item37'];?></td>
        <?php endwhile?>
      </tr>
      </tbody>
      </div>
  </table>
       



