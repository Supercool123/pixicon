<?php
include('db_config.php');
new Database();
$test = "SELECT * FROM rate_hair order by 1  DESC  LIMIT 0,1";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>





<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<table class="table table-striped" style="font-weight: bold;">
           <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12 col-centered">
     <thead>
      <tr>
        <th style="background-color:#000000;color:#fff"><h4>Hair Care Styling</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Blowdry-Upto Shoulder</td>
         <?php while($row = mysql_fetch_array($fetch_data)):?>
        <td>&#8377;<?php echo $row['rate_item1'];?></td>
        
      </tr>
      <tr>
        <td>Blowdry-below sholder</td>
        <td>&#8377;<?php echo $row['rate_item2'];?></td>
       
      </tr>
      <tr>
        <td>Blowdry-Upto Waist</td>
        <td>&#8377;<?php echo $row['rate_item3'];?></td>
      </tr>
      <tr>
        <td>Ironing-upto shoulder</td>
       <td>&#8377;<?php echo $row['rate_item4'];?></td>
        
      </tr>
      <tr>
        <td>Ironing-Below Shoulder</td>
        <td>&#8377;<?php echo $row['rate_item5'];?></td>
      </tr>
      <tr>
       
      <tr>
        <td>Ironing-upto waist</td>
        <td>&#8377;<?php echo $row['rate_item6'];?></td>
      </tr>
      <tr>
        <td>Curling(Medium Hair)</td>
        <td>&#8377;<?php echo $row['rate_item7'];?></td>
      </tr>
      <tr>
        <td>Curling(Long hair)</td>
        <td>&#8377;<?php echo $row['rate_item8'];?></td>
      </tr>
      
      <th style="background-color:#000000;color:#fff"><h4>Hair spa/Treatment </h4></th><th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      <tr>
        <td>Upto Shoulder</td>
        <td>&#8377;<?php echo $row['rate_item9'];?></td>
      </tr>
        <tr>
        <td>Below Shoulder</td>
        <td>&#8377;<?php echo $row['rate_item10'];?></td>
      </tr>
            <tr>
        <td>Below Wais</td>
        <td>&#8377;<?php echo $row['rate_item11'];?></td>
      </tr>
            <tr>
        <td>Anti Hairfall Treatment</td>
        <td>&#8377;<?php echo $row['rate_item12'];?></td>
      </tr>
            <tr>
        <td>Anti Dandruff Treatment</td>
        <td>&#8377;<?php echo $row['rate_item13'];?></td>
      </tr>
      <tr>
        <td>Protiene Booster(Add On)</td>
        <td>&#8377;<?php echo $row['rate_item14'];?></td>
      </tr>

<th style="background-color:#000000;color:#fff"><h4>Hair Cut</h4></th><th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      <tr>
        <td>Blow dry/Hair setting(Add on with Haircut)</td>
        <td>&#8377;<?php echo $row['rate_item15'];?></td>
      </tr>
      <tr>
        <td>Deep U</td>
        <td>&#8377;<?php echo $row['rate_item16'];?></td>
      </tr>
      <tr>
        <td>Feather</td>
        <td>&#8377;<?php echo $row['rate_item17'];?></td>
      </tr>
      <tr>
        <td>Kids</td>
        <td>&#8377;<?php echo $row['rate_item18'];?></td>
      </tr>
      <tr>
        <td>Layer</td>
        <td>&#8377;<?php echo $row['rate_item19'];?></td>
      </tr>
      <tr>
        <td>Re styling</td>
        <td>&#8377;<?php echo $row['rate_item20'];?></td>
      </tr>
        <tr>
        <td>Step</td>
        <td>&#8377;<?php echo $row['rate_item21'];?></td>
      </tr>
      <tr>
        <td>Straight</td>
        <td>&#8377;<?php echo $row['rate_item22'];?></td>
      </tr>
      <tr>
        <td>Trim</td>
        <td>&#8377;<?php echo $row['rate_item23'];?></td>
      </tr>
      <tr>
        <td>U</td>
        <td>&#8377;<?php echo $row['rate_item24'];?></td>
      </tr>
      
     <th style="background-color:#000000;color:#fff"> <h4>Hair Color</h4></th><th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
     
     
      <tr>
        <td>Henna Application(customer colors)</td>
        <td>&#8377;<?php echo $row['rate_item25'];?></td>
      </tr>
      <tr>
        <td>Root Touchup(cstomer colors)</td>
        <td>&#8377;<?php echo $row['rate_item26'];?></td>
      </tr>
      <tr>
        <td>Global Color(customer Colors)</td>
        <td>&#8377;<?php echo $row['rate_item27'];?></td>
      </tr>
      <tr>
        <td>Root Touchup(Sassy colors)</td>
        <td>&#8377;<?php echo $row['rate_item28'];?></td>
      </tr>
      <tr>
        <td>Root Toch-Inoa(Sassy colors)</td>
        <td>&#8377;<?php echo $row['rate_item29'];?></td>
      </tr>
      <tr>
        <td>Global Colors(Sassy Colors)</td>
        <td>&#8377;<?php echo $row['rate_item30'];?></td>
      </tr>
      <tr>
        <td>Global Highlights(Sassy colors)</td>
        <td>&#8377;<?php echo $row['rate_item31'];?></td>
      </tr>
      <tr>
        <td>Color Streaks</td>
        <td>&#8377;<?php echo $row['rate_item32'];?></td>
      </tr>
      <tr>
        <td>Straghtening-Below Shoulder</td>
        <td>&#8377;<?php echo $row['rate_item33'];?></td>
      </tr>
      <tr>
        <td>Smoothening-Below Waist</td>
        <td>&#8377;<?php echo $row['rate_item34'];?></td>
      </tr>
       <?php endwhile?>
      </tbody>
      </div>
  </table>
  
</body>
</html>


