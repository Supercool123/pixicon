
<body>

<div class="container">
  
  <div class="modal fade" id="terms" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
           <h2 class="section-heading" style="color:#ff6699;font-weight:bold">TERMS AND CONDITIONS:</h2>
                    
                    <p class="section-paragraph" style="color:#ff6699;font-weight:bold">Welcome to the Sassy, a website located at www.sassysalon.com (the "Site"). By using this website and/or placing a request, you agree to be bound by these terms and conditions as set out below. This Website is owned and operated by Sassy- ("we" or "us") for your On-demand in-home beauty services. Please feel free to browse the Website, however, your access and use of the Website is subjected to the following terms and conditions ("Terms and Conditions") and all applicable laws. By using and browsing this Website, you accept, without limitation or qualification, the Terms and Conditions. If you do not agree with any of the below Terms and Conditions, do not use this Website. We reserve the right, in our sole discretion, to modify, alter or otherwise update these Terms and Conditions at any time and you agree to be bound by such modifications, alterations or updates.<br>

Copyright & Trademarks, Conditions of Website Use<br>

All Website design, text, movies, graphics, the selection and arrangement thereof and all software compilations, underlying source code, software (including applets) and all other material on this Website are copyright Sassy and its affiliates or their content and technology providers.<br><br>

All Rights Reserved<br><br>

Any use of materials on this Website, including reproduction for purposes other than those noted above, modification, distribution, or re-publication, without the prior written permission of Sassysalon.com, is strictly prohibited.<br></p>
                

    <!-- Fixed Height Image Aside -->
    <!-- Image backgrounds are set within the full-width-pics.css file. -->
        <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p style="color:#ff6699;font-weight:bold">Copyright &copy; Sassy Salon Services 2016</p>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </footer>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
