
<?php

new Database();
$test = "SELECT * FROM rate_nails order by 1  DESC  LIMIT 0,1";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>





<table class="table " style="font-weight: bold;">
            <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12 col-centered">
    <thead>
      <tr>
        <th style="background-color:#000000;color:#fff"><h4>Nail</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Nail Polish(Application)</td>
        <?php while($row = mysql_fetch_array($fetch_data)):?>
        <td>&#8377;<?php echo $row['rate_nail_item1'];?></td>
        
      </tr>
      <tr>
        <td>Basic Manicure</td>
        <td>&#8377;<?php echo $row['rate_nail_item2'];?></td>
       
      </tr>
      <tr>
        <td>Basic Pedicure</td>
        <td>&#8377;<?php echo $row['rate_nail_item3'];?></td>
      </tr>
      <tr>
        <td>Manicure(Aroma)</td>
       <td>&#8377;<?php echo $row['rate_nail_item4'];?></td>
        
      </tr>
      <tr>
        <td>Pedicure(Aroma)</td>
        <td>&#8377;<?php echo $row['rate_nail_item5'];?></td>
      </tr>
      <tr></td>
        <td>Hand Spa
        <td>&#8377;<?php echo $row['rate_nail_item6'];?></td>
      </tr>
      <tr>
        <td>Foot Spa</td>
        <td>&#8377;<?php echo $row['rate_nail_item7'];?></td>
      </tr>
    <?php endwhile ?>
      </tbody>
      </div>
  </table>