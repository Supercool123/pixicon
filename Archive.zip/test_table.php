<?php
include('db_config.php');
new Database();
$test = "SELECT * FROM price_details order by 1  DESC  LIMIT 0,5";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>
<head>
 
  <style type="text/css">
  .table-striped > tbody > tr:nth-child(2n+1) > td, .table-striped > tbody > tr:nth-child(2n+1) > th {
   background-color:rgba(135,83,162,0.5);}
   h5{
    color:#101010;
   }
   .borderless td, .borderless th {
    border: none;
}
</style>
</head>
<center><h2  style="padding-top:10%">Packages</h2></center>
<center><hr class="sep"></center>
<div class="container" >
<?php while($row = mysql_fetch_array($fetch_data)):?>
<div class="col-xs-12 col-sm-12 col-lg-4 col-md-4" style="padding-bottom:3%">  
<table class=" table-borderless"  style="width:100%;background-color:rgba(135,83,162,0.25);">
    
<thead style="background-color:rgba(0,0,0,0.7);">
<th><center><h3 style="color:#fff;font-weight:bold"><?php echo $row['packages_name'];?></h3></center> <br><center><h2 style="color:#fff"> &#8377;<?php echo $row['packages_price'];?></h2></center></th>
</thead>
<tbody>
  <tr>
    <td><h5><center><?php echo $row['packages_item1'];?></center></h5></td>
  </tr>
  <tr>
    <td><h5><center><?php echo $row['packages_item2'];?></center></h5></td>
  </tr>
  <tr>

 
    <td><h5><center><?php echo $row['packages_item3'];?></center></h5></td>
  </tr>
  <tr>
    <td><h5><center><?php echo $row['packages_item4'];?></center></h5></td>
  </tr>
  <tr>
    <td><h5><center><?php echo $row['packages_item5'];?></center></h5></td>
  </tr>
  <tr>
    <td><h5><center><?php echo $row['packages_item6'];?></center></h5></td>
  </tr>
  <tr>
    <td><h5><center><?php echo $row['packages_item7'];?></center></h5></td>
  </tr>
  <tr>
    <td><h5><center><?php echo $row['packages_item8'];?></center></h5></td>
  </tr>
  <tr>
    <td><h5><center><?php echo $row['packages_item9'];?></center></h5></td>
  </tr>
  <tr>
  <td>
  <center><button data-toggle="modal" data-target="#form" style="background-color:#ff2483;">Book Now</button></center>
  </td>
  </tr>
</tbody>
</table>
</div>
<?php endwhile?>  
</div>