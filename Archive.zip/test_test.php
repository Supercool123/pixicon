<?php
include('db_config.php');
new Database();
$test = "SELECT * FROM price_details order by 1  DESC  LIMIT 0,5";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>

<!DOCTYPE html>
<html>
<style>
.tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    
    /* Position the tooltip */
    position: absolute;
    z-index: 1;
    top: 100%;
    left: 50%;
    margin-left: -60px;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
}
</style>
<body style="text-align:center;">

<h2>Bottom Tooltip</h2>
<p>Move the mouse over the text below:</p>
<?php while($row = mysql_fetch_array($fetch_data)):?>
 <div class="col-xs-12 col-sm-12 col-lg-4 col-md-4" >  
   
<div class="tooltip">Hover over me
  <span class="tooltiptext"><table class=" table-bordered " style="width:100%;padding-bottom:10%;background-color:rgba(135,83,162,0.5);">
    
<thead style="background-color:rgba(0,0,0,0.7);">
<th><center><h3 style="color:#fff;font-weight:bold"><?php echo $row['packages_name'];?></h3></center> <br><center><h2 style="color:#fff"> &#8377;<?php echo $row['packages_price'];?></h2></center></th>
</thead>
<tbody>
  <tr>
    <td><h4><?php echo $row['packages_item1'];?></h4></td>
  </tr>
  <tr>
    <td><h4><?php echo $row['packages_item2'];?></h4></td>
  </tr>
  <tr>

 
    <td><h4><?php echo $row['packages_item3'];?></h4></td>
  </tr>
  <tr>
    <td><h4><?php echo $row['packages_item4'];?></h4></td>
  </tr>
  <tr>
    <td><h4><?php echo $row['packages_item5'];?></h4></td>
  </tr>
  <tr>
    <td><h4><?php echo $row['packages_item6'];?></h4></td>
  </tr>
  <tr>
    <td><h4><?php echo $row['packages_item7'];?></h4></td>
  </tr>
  <tr>
    <td><h4><?php echo $row['packages_item8'];?></h4></td>
  </tr>
  <tr>
    <td><h4><?php echo $row['packages_item9'];?></h4></td>
  </tr>
  <tr>
  <td>
  <center><button data-toggle="modal" data-target="#form" style="background-color:#ff2483;">Book Now</button></center>
  </td>
  </tr>
</tbody>
</table></span>
</div>
</div>
<?php endwhile ?>
</body>
</html>

