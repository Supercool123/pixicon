<!-- team -->
<?php
include('dbconfig.php');
    $sql="SELECT * FROM tbl_uploads order by 1  DESC  LIMIT 0,3";
    $result_set=mysql_query($sql);
    ?>

<center><h2 class="  wowload fadeInUp" style="padding-top:10%">Offers</h2></center>
<center><hr class="sep"></center>
<div class="row grid team  wowload fadeInUpBig">
<?php while($row=mysql_fetch_array($result_set)):?>  
  <div class=" col-sm-4 col-xs-12" style="padding-bottom:10%">
  
        <img src="uploads/<?php echo $row['file'] ?>" style="height:100%;width:100%;">
        
        </div>
<?php endwhile?>
   
 

<!-- team -->

</div>