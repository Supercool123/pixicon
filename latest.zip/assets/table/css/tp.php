<?php
include('db_config.php');
new Database();
$test = "SELECT * FROM price_details order by 1  DESC  LIMIT 0,3";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>



<!-- Pricing Table Section -->

     <div id="pricing" class="container" >
         <?php while($row = mysql_fetch_array($fetch_data)):?>
     <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" >
  
  <div class="price_card alpha wowload fadeInLeft">
    <div class="header">
      <span class="price"><?php echo $row['packages_name'];?></span>


      <span class="name">&#8377;<?php echo $row['packages_price'];?></span>
       
    </div>
    
    <ul class="features">
      <li><?php echo $row['packages_item1'];?></li>
      <li><?php echo $row['packages_item2'];?></li>
      <li><?php echo $row['packages_item3'];?></li>
      <li><?php echo $row['packages_item4'];?></li>
      <li><?php echo $row['packages_item5'];?></li>
      <li><?php echo $row['packages_item6'];?></li>
      <li><?php echo $row['packages_item7'];?></li>
      <li><?php echo $row['packages_item8'];?></li>
      <li><?php echo $row['packages_item9'];?></li>
    </ul>
     <button data-toggle="modal" data-target="#myModal">Book Now</button>
    
      </div>
      
 
  
 </div>
  <?php endwhile?>
  </div>

 <!--<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" style="padding-left:30px">
  <div class="price_card bravo wowload fadeInLeft">
    <div class="header">
      <span class="price">&#8377;2699</span><br><br>

      <span class="name"><?php echo $row['packages_name'];?></span>
       
    </div>
    <ul class="features">
      <li>1. Harbal Head Massage</li>
      <li>2. VLCC Instaglow</li>
      <li>3. Manicure – Regular</li>
      <li>4. Pedicure – Regular</li>
      <li>5. Full Hands Waxing – Rica</li>
      <li>6. Full Legs Waxing – Rica</li>
      <li>7. Threading – Eyebrows & Upperlip</li>
    </ul>
    <button data-toggle="modal" data-target="#myModal">Book Now</button>
    <span class="tip">* Most popular!</span>-->




