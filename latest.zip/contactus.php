<div class="container">
 <!-- Modal -->
  <div class="modal fade" id="con" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color:rgba(94,94,94,0.83);color:#fff">
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
          
        </div>
        <div class="modal-body">
          <h2>CONTACT US:</h2><br>
          <P><i class="fa fa-map-marker fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;286, 1st Floor, Beside Karande Jewelers, Coffee House Square, Nagpur, Maharashtra 440010</P><br>
          <P><i class="fa fa-phone fa-2x" aria-hidden="true" style="color:#fff;"></i> &nbsp;&nbsp;&nbsp;+91-9130936340</P><br>
          <p><i class="fa fa-whatsapp fa-2x" style=" color:#fff;"></i> &nbsp;&nbsp;&nbsp;+91-9850690802</p><br>
          <p><i class="fa fa-google-plus-official fa-2x" aria-hidden="true" style="color:#fff;"></i>&nbsp;&nbsp;&nbsp;sassyhomeservices@gmail.com</p><br>
          <a href="https://www.facebook.com/Sassy-1623316271252871/?fref=ts" target="_blank"><i class="fa fa-facebook fa-2x" style="color:#fff;"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="https://www.instagram.com/sassy.salon/" target="_blank"><i class="fa fa-instagram fa-2x" style="color:#fff;"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="https://twitter.com/salon_sassy" target="_blank"><i class="fa fa-twitter fa-2x" style="color:#fff;"></i></a>   
<br><br><br><br>
   

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    
                    <p style="color:#fff;font-weight:bold">Copyright &copy; Sassy Salon Services 2016</p>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </footer>

              
                   
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

