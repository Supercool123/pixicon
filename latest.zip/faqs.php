

  
<div class="container">
 <!-- Modal -->
  <div class="modal fade" id="faq" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color:rgba(94,94,94,0.83);color:#fff">
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
          
        </div>
        <div class="modal-body">
           <h2 class="section-heading" style="color:#fff;font-weight:bold">Frequently Asked Questions:</h2>
                    <br><br><br><br>
                    <p class="section-paragraph" style="color:#fff">
                        <h4>1. How can I trust Sassy to provide professional services?</h4><br>



<h5 style="color:#fff">At Sassy we only on-board, trained, experienced & verified beauty professional. Each one of the professional has been hand picked, verified & trained by our Skin expert before being allowed to perform services.</h5><br>

<hr>

<h4>2. How do you take care of the quality of service, hygiene and cleanliness?</h4><br>



<h5 style="color:#fff">Our beauticians will be carrying all the equipment's and quality products along with them. As far as possible we use single serve mono dose kits for most of the services. In addition we also use disposables like gowns, towels, etc to maintain a high standard of cleanliness and hygiene.</h5><br>

<hr>

<h4>3. What is the quality of the cosmetics products that beauticians use? How do we know if they are genuine?</h4><br>



<h5 style="color:#fff">Sassy beauty therapists carry a kit with all the products, which are sourced by us from brand stores. Our therapists carry products from well-known brands like VLCC, Lakme, Cheryl's, and L’Oreal.</h5><br>


<hr>


<h4>4. What are your work timings?</h4><br>



<h5 style="color:#fff">We offer services from morning 10AM to 7PM, all 7 days in a week. We shall shortly be starting pre 10AM & post 7PM services as well.</h5><br>

<hr>

<h4>5.Can I cancel/modify the appointment once made?</h4><br>



<h5 style="color:#fff">Ofcourse, but we would request you to inform us atleast an hour so that we can avoid unnecessary hassles for our professionals.</h5><br>

<hr>

<h4>6. Are there additional charges for home visit?</h4><br>



<h5 style="color:#fff">There are no additional or any hidden charges, other than what is mentioned on our website.</h5> <br>

<hr>

<h4>7. Do you provide similar services for men?</h4><br>



<h5 style="color:#fff">Not yet, we currently have services only for women provided by women. We shall keep you posted when we launch services for men.</h5><br>
                    </p>
  
        
              
                    
    

         
    
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p style="color:#fff;font-weight:bold">Copyright &copy; Sassy Salon Services 2016</p>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </footer>

              
                   
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

