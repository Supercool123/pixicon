<div class="modal fade" id="form2" role="dialog">
    <div class="modal-dialog ">
    
      <!-- Modal content-->
      <div class="modal-content" >
      
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
           
        </div>
        <div class="modal-body">
        
           <form id="contact" action="" method="post">
    
    <h4>One Step Towards Sassiness.</h4>
    <fieldset>
      <input placeholder="Your name" type="text" tabindex="1"  autofocus>
    </fieldset>
    <fieldset>
      <input placeholder="Your Email Address(optional)" type="email" tabindex="2" >
    </fieldset>
    <fieldset>
      <input placeholder="Your Phone Number " type="tel" tabindex="3" >
    </fieldset>
    <fieldset>
      <input placeholder="Your Address (optional)" type="text"  tabindex="4" >
    </fieldset>
    <fieldset>
     <label>Time  :  24 hour format</label> <input placeholder="TIME" type="time" name="" maxlength="2" size="2" >
    </fieldset>
    <fieldset>
      <label>Date :</label><input type="date" name="" maxlength="2" size="2" >
    </fieldset>
    <fieldset>
      <textarea placeholder="Type your message here...." tabindex="5" ></textarea>
    </fieldset>
    <fieldset>
      <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Submit</button><br>
      <h6>Kindly Book An Appointment 2 Hours Before Required Time</h6>
    </fieldset> 
  
  </form>
  
       
        <div class="modal-footer">
         
          
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>

    </div>
  </div>
 </div> 




