<?php
class Database {
	  // phpinfo();
	
		public $data = "";
		
		const DB_SERVER = "localhost";
		// const DB_SERVER = "mysql.2freehosting.com";
		const DB = "sassy";
		// const DB = "u161389876_data1";
		const DB_USER = "root";
		//  const DB_USER = "u161389876_data1";
		const DB_PASSWORD = "";
		// const DB_PASSWORD = "sassy123";
		
		
		private $db = NULL;
	
		public function __construct(){
			$this->dbConnect();					// Initiate Database connection
		}
		
		
		private function dbConnect(){
			// phpinfo();
			$this->db = mysql_connect(self::DB_SERVER,self::DB_USER,self::DB_PASSWORD);
			if($this->db)
				mysql_select_db(self::DB,$this->db);
		}
		
}

?>