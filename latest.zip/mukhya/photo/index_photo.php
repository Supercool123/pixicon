<?php
include_once 'dbconfig.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Sassy Salon Services</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="simple-sidebar.css">
</head>
<body>
<div id="header">
<label>Update Offers</label>
</div>
<!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li>
                    <a href="../home.html">HOME</a>
                </li>
                <li>
                    <a href="../rate_card.html">RATE CARD SET 1</a>
                </li>
                <li>
                    <a href="../rate_card2.html">RATE CARD SET 2</a>
                </li>
                <li>
                    <a href="photo/index_photo.php">OFFERS</a>
                </li>
                <li>
                    <a href="../package_table.html">PACKAGES</a>
                </li>
                <li><a href="../logout.php">logout</a></li>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->
<div id="body">
	<form action="upload.php" method="post" enctype="multipart/form-data">
	<input type="file" name="file" />
	<button type="submit" name="btn-upload">upload</button>
	</form>
    <br /><br />
    <?php
	if(isset($_GET['success']))
	{
		?>
        <label>File Uploaded Successfully...  <a href="view.php">click here to view file.</a></label>
        <?php
	}
	else if(isset($_GET['fail']))
	{
		?>
        <label>Problem While File Uploading !</label>
        <?php
	}
	else
	{
		?>
        <label>Try to upload any files(PDF, DOC, EXE, VIDEO, MP3, ZIP,etc...)</label>
        <?php
	}
	?>
</div>
<div id="footer">
<label>By <a href="http://cleartuts.blogspot.com">cleartuts.blogspot.com</a></label>
</div>
</body>
</html>