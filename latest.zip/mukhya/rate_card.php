<?php
include('db_config.php');
// include('connection.php');
New Database();
print_r($_POST);
$rate_item1 = $_POST['rate_item1'];
$rate_item2 = $_POST['rate_item2'];
$rate_item3 = $_POST['rate_item3'];
$rate_item4 = $_POST['rate_item4'];
$rate_item5 = $_POST['rate_item5'];
$rate_item6 = $_POST['rate_item6'];
$rate_item7 = $_POST['rate_item7'];
$rate_item8 = $_POST['rate_item8'];
$rate_item9 = $_POST['rate_item9'];
$rate_item10 = $_POST['rate_item10'];
$rate_item11 = $_POST['rate_item11'];
$rate_item12 = $_POST['rate_item12'];
$rate_item13 = $_POST['rate_item13'];
$rate_item14 = $_POST['rate_item14'];
$rate_item15 = $_POST['rate_item15'];
$rate_item16 = $_POST['rate_item16'];
$rate_item17 = $_POST['rate_item17'];
$rate_item18 = $_POST['rate_item18'];
$rate_item19 = $_POST['rate_item19'];
$rate_item20 = $_POST['rate_item20'];
$rate_item21 = $_POST['rate_item21'];
$rate_item22 = $_POST['rate_item22'];
$rate_item23 = $_POST['rate_item23'];
$rate_item24 = $_POST['rate_item24'];
$rate_item25 = $_POST['rate_item25'];
$rate_item26 = $_POST['rate_item26'];
$rate_item27 = $_POST['rate_item27'];
$rate_item28 = $_POST['rate_item28'];
$rate_item29 = $_POST['rate_item29'];
$rate_item30 = $_POST['rate_item30'];
$rate_item31 = $_POST['rate_item31'];
$rate_item32 = $_POST['rate_item32'];
$rate_item33 = $_POST['rate_item33'];
$rate_item34 = $_POST['rate_item34'];
$rate_item35 = $_POST['rate_item35'];

/*Query to insert packages details in Database*/
$insert_rate_details = 'INSERT INTO rate_hair(`rate_item1`,`rate_item2`,`rate_item3`,`rate_item4`,`rate_item5`,`rate_item6`,`rate_item7`,`rate_item8`,`rate_item9`,`rate_item10`,`rate_item11`,`rate_item12`,`rate_item13`,`rate_item14`,`rate_item15`,`rate_item16`,`rate_item17`,`rate_item18`,`rate_item19`,`rate_item20`,`rate_item21`,`rate_item22`,`rate_item23`,`rate_item24`,`rate_item25`,`rate_item26`,`rate_item27`,`rate_item28`,`rate_item29`,`rate_item30`,`rate_item31`,`rate_item32`,`rate_item33`,`rate_item34`,`rate_item35`) VALUES ("'.$rate_item1.'","'.$rate_item2.'","'.$rate_item3.'","'.$rate_item4.'","'.$rate_item5.'","'.$rate_item6.'","'.$rate_item7.'","'.$rate_item8.'","'.$rate_item9.'","'.$rate_item10.'","'.$rate_item11.'","'.$rate_item12.'","'.$rate_item13.'","'.$rate_item14.'","'.$rate_item15.'","'.$rate_item16.'","'.$rate_item17.'","'.$rate_item18.'","'.$rate_item19.'","'.$rate_item20.'","'.$rate_item21.'","'.$rate_item22.'","'.$rate_item23.'","'.$rate_item24.'","'.$rate_item25.'","'.$rate_item26.'","'.$rate_item27.'","'.$rate_item28.'","'.$rate_item29.'","'.$rate_item30.'","'.$rate_item31.'","'.$rate_item32.'","'.$rate_item33.'","'.$rate_item34.'","'.$rate_item35.'") ';
// echo $insert_packages_details;
$inserted = mysql_query($insert_rate_details);
header('Location:rate_card.html');
/*$test = "SELECT * FROM ";
$fetch_data  = mysql_query($test) or die(mysql_error());
while($row = mysql_fetch_array($fetch_data)){
echo $row['packages_name'];
}*/
?>