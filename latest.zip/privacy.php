

<div class="container">
 <!-- Modal -->
  <div class="modal fade" id="privacy" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color:rgba(94,94,94,0.83);color:#fff">
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
          
        </div>
        <div class="modal-body">
          

        
              
                   <h2 style="color:#ff6699"> Sassy Salons – Website Privacy Policy Agreement</h2>

<h4>Sassy Salons recognises the importance of maintaining your privacy. We value your privacy and appreciate your trust in us. This Policy describes how we treat user information we collect on www.sassysalon.in and other offline sources. This Privacy Policy applies to current and former visitors to our website and to our online customers. By visiting and/or using our website, you agree to this Privacy Policy.<br>

Sassy Salons is a property of Sassy Salons, 286, 1st Floor, Beside Karande Jewelers, Coffee House Square, Dharampeth, Nagpur, Maharashtra 440010.</h4><br>

<h3>INFORMATION WE COLLECT</h3><br>

<h4>Contact information. We collect your Name, Email, Phone, Address.

Payment and billing information. We will collect your billing name, billing address and payment method. We NEVER collect your credit card number or credit card expiry date or other details pertaining to your credit card on our website. Credit card information will be obtained and processed by our online.<br>

Demographic information. We may collect demographic information about you, or any other information provided by you during the use of our website. We might also collect this as a part of a survey from time to time.<br>

Other information. If you use our website, we may collect information about your IP address and the browser you’re using. We might look at what site you came from, duration of time spent on our website, pages accessed or what site you visit when you leave us. We might also collect the type of mobile device you are using, or the version of the operating system your computer or device is running.</h4><br>

<h3>WE COLLECT INFORMATION IN DIFFERENT WAYS.</h3><br>

<h4>We collect information directly from you. We collect information directly from you when you contact us. We also collect information that you post as a comment on our website or ask us a question through phone or via email.<br>

We also collect information from you passively. We use tracking tools like Google Analytics, Google Webmaster, browser cookies and web beacons for collecting information about your usage of our website.</h4>

<h3>USE OF YOUR PERSONAL INFORMATION</h3>

<h4>We use information to contact you: We might use the information you provide to contact you for confirmation of a purchase on our website or for other promotional purposes. We use information to respond to your requests or questions. We might use your information to confirm your registration for an event or contest.<br>

We use information to improve our products and services. We might use your information to customize your experience with us. This could include displaying content based upon your preferences.<br>

We use information to look at site trends and customer interests. We may use your information to make our website and products better. We may combine information we get from you with information about you we get from third parties.<br>

We use information for security purposes. We may use information to protect our company, our customers, or our websites.<br>

We use information for marketing purposes. We might send you information about special promotions or offers. We might also tell you about new features or products. These might be our own offers or products, or third-party offers or products we think you might find interesting. Or, for example, if you buy product(s) from us we’ll enrol you in our newsletter.<br>

We use information to send you transactional communications. We might send you emails or SMS about your account or a purchase.<br>

We use information as otherwise permitted by law.<br></h4>

<h3>EMAIL OPT-OUT</h3>

<h4>You can opt out of receiving our marketing emails. To stop receiving our promotional emails, please send an email contact@Sassysalons.com. It may take about ten days to process your request. Even if you opt out of getting marketing messages, we will still be sending you transactional messages through email and SMS about your purchases.<br></h4>

<h3>THIRD PARTY SITES</h3>

<h4>If you click on one of the links to third party websites, you may be taken to websites we do not control. This policy does not apply to the privacy practices of those websites. Read the privacy policy of other websites carefully. We are not responsible for these third party sites.<br>

Grievance Redressal<br>

In case of any grievance please contact the following:<br>

Jyoti Khatle<br>

286, 1st Floor, Beside Karande Jewelers, Coffee House Square, Near Mayur Stationery, Dharampeth, Nagpur, Maharashtra 440010<br>

Phone: 9130936340 Email : sassyhomesalon@gmail.com<br>

If you have any questions about this Policy or other privacy concerns, you can also email us at sassyhomesalon@gmail.com.<br>
</h4>
<h3>UPDATES TO THIS POLICY</h3>

<h4>This Privacy Policy was last updated on 19-01-2016. From time to time we may change our privacy practices. We will notify you of any material changes to this policy as required by law. We will also post an updated copy on our website. Please check our site periodically for updates.</h4>

<h3>JURISDICTION</h3>

<h4>If you choose to visit the website, your visit and any dispute over privacy is subject to this Policy and the website’s terms of use. In addition to the foregoing, any disputes arising under this Policy shall be governed by the laws of Nagpur.</h4>

    <!-- Fixed Height Image Aside -->
    <!-- Image backgrounds are set within the full-width-pics.css file. -->
    
    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p style="color:#ff6699;font-weight:bold">Copyright &copy;Sassy Salon Services 2016</p>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </footer>

    


        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

