// JavaScript Document
var fadeShow = $(".background").fadeShow({

	correctRatio: true,

	shuffle: true,

	speed: 2500,

	images: ['images/bg-image.jpg',

			 'images/bg-image-1.jpg']



});