
  
<div class="container">
 <!-- Modal -->
  <div class="modal fade" id="aboutus" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
          
        </div>
        <div class="modal-body">
           <p class="section-paragraph" style="color:#ff6699;font-weight:bold"><font style="width:200px">Caught between your hectic daily schedules? Finding it difficult to find time to relax and de-stress? Wish you had your very own personal beautician answering your every beck and call... your search ends here with Sassy Salon. At Sassy we believe each one us deserves to be treated as a princess and without the hassle of wasting your precious time waiting in a queue. We at Sassy provide best beauty professionals at your doorstep. <br><br><br><br>

So sit back, relax and indulge yourself with a personal treat with Sassy Salon. Get your next hair style, facial, waxing, threading, manicure, pedicure, haircut, bridal makeup, makeover or other parlour services at your doorstep. </font></p>
  
        
              
                    
    

         
    
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p style="color:#ff6699;font-weight:bold">Copyright &copy; Sassy Salon Services 2016</p>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </footer>

              
                   
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

