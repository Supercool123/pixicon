
$('#submit_booking').click(function(){
// alert('Hello i m in residential_preclas');
var stud_last_stand= $('#name_id').val();     
var stud_last_board= $('#email_id').val();     
var stud_last_perc= $('#phone_id').val();     
var stud_last_school= $('#add_id').val();     
var stud_last_city= $('#time_id').val();     
var stud_last_state= $('#date_id').val();     
var stud_last_country= $('#services_id').val();  

 // alert('A1'+stud_last_stand+'A2'+stud_last_board+'city'+stud_last_perc+'st'+stud_last_school+'pinc'+stud_last_city+'resc'+stud_last_state+'hidd'+stud_last_country);
	$.ajax({
		type:"POST",
		url:'../sending_mail.php',
		data:{
		name:stud_last_stand,
		email:stud_last_board,
		phone:stud_last_perc,
		add:stud_last_school,
		time:stud_last_city, 
		date:stud_last_state,                  
		message:stud_last_country,

		},
		success:function(response){
		alert(response);
		/*                    if(response=='succ'){
		// alert("You have successuflly Logged In");
		parent_afterRegLogin();
		}
		else {
		alert("Please enter all Mandatory Fields! ");
		// window.location.replace("login.php");
		}*/
		}
	});
});