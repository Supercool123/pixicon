

  
<div class="container">
 <!-- Modal -->
  <div class="modal fade" id="faq" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
          
        </div>
        <div class="modal-body">
           <h2 class="section-heading" style="color:#ff6699;font-weight:bold">Frequently Asked Questions:</h2>
                    <br><br><br><br>
                    <p class="section-paragraph" style="color:#ff6699;">
                        <font style="font-weight:bold;font-size:24px">1. How can I trust Sassy to provide professional services?</font><br>



<font style="font-size:24px">At Sassy we only on-board, trained, experienced & verified beauty professional. Each one of the professional has been hand picked, verified & trained by our Skin expert before being allowed to perform services.</font><br>

<hr>

<font style="font-weight:bold;color:#ff6699;font-size:24px">2. How do you take care of the quality of service, hygiene and cleanliness?</font><br><br>



<font style="color:#ff6699;font-size:24px">Our beauticians will be carrying all the equipment's and quality products along with them. As far as possible we use single serve mono dose kits for most of the services. In addition we also use disposables like gowns, towels, etc to maintain a high standard of cleanliness and hygiene.</font><br>

<hr>

<font style="font-weight:bold;color:#ff6699;font-size:24px">3. What is the quality of the cosmetics products that beauticians use? How do we know if they are genuine?</font><br><br>



<font style="color:#ff6699;font-size:24px">Sassy beauty therapists carry a kit with all the products, which are sourced by us from brand stores. Our therapists carry products from well-known brands like VLCC, Lakme, Cheryl's, and L’Oreal.</font><br>


<hr>


<font style="font-weight:bold;color:#ff6699;font-size:24px">4. What are your work timings?</font><br><br>



<font style="color:#ff6699;font-size:24px">We offer services from morning 10AM to 7PM, all 7 days in a week. We shall shortly be starting pre 10AM & post 7PM services as well.</font><br>

<hr>

<font style="font-weight:bold;color:#ff6699;font-size:24px">5.Can I cancel/modify the appointment once made?</font><br><br>



<font style="color:#ff6699;font-size:24px">Ofcourse, but we would request you to inform us atleast an hour so that we can avoid unnecessary hassles for our professionals.</font><br>

<hr>

<font style="font-weight:bold;color:#ff6699;font-size:24px">6. Are there additional charges for home visit?</font><br><br>



<font style="color:#ff6699;font-size:24px">There are no additional or any hidden charges, other than what is mentioned on our website.</font> <br>

<hr>

<font style="font-weight:bold;color:#ff6699;font-size:24px">7. Do you provide similar services for men?</font><br><br>



<font style="color:#ff6699;font-size:24px">Not yet, we currently have services only for women provided by women. We shall keep you posted when we launch services for men.</font><br>
                    </p>
  
        
              
                    
    

         
    
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p style="color:#ff6699;font-weight:bold">Copyright &copy; Sassy Salon Services 2016</p>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </footer>

              
                   
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

