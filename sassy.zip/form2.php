<div class="modal fade" id="form2" role="dialog">
    <div class="modal-dialog ">
    
      <!-- Modal content-->
      <div class="modal-content" >
      
        <div class="modal-header">
          <a type="button" class="close" data-dismiss="modal">&times;</a>
           
        </div>
        <div class="modal-body">
        
            <form id="contact" action="#" method="post">
    
    <h4>One Step Towards Sassiness.</h4>
    <fieldset>
      <input placeholder="Your name" type="text" tabindex="1"   maxlength="100" id="name_id" required>
    </fieldset>
    <fieldset>
      <input placeholder="Your Email Address(optional)" type="email" tabindex="2"  maxlength="150" id="email_id" required>
    </fieldset>
    <fieldset>
      <input placeholder="Your Phone Number " type="tel" tabindex="3"  maxlength="10" id="phone_id" required>
    </fieldset>
    <fieldset>
      <input placeholder="Your Address (optional)" type="text"  tabindex="4" maxlength="600" id="add_id" required>
    </fieldset>
    <fieldset>
     <label>Time  :  24 hour format</label> <input  type="time"   size="2" id="time_id" required>
    </fieldset>
    <fieldset>
      <label>Date :</label><input type="date"   size="2" id="date_id" required>
    </fieldset>
    <fieldset>
      <textarea placeholder="Enter your services here" tabindex="5"  maxlength="300" id="message" required></textarea>
    </fieldset>
    <fieldset>
      <button  type="submit" id="submit_booking">Submit</button><br>
      <h6>We are always here for your last minute services. However, we request you to book your appointment at least 2 hours before so as to avoid inconvenience.</h6>
    </fieldset> 
  
  </form>
  <script type="text/javascript">

$('#submit_booking').click(function(){
// alert('Message has been sent');
var stud_last_stand= $('#name_id').val();     
var stud_last_board= $('#email_id').val();     
var stud_last_perc= $('#phone_id').val();     
var stud_last_school= $('#add_id').val();     
var stud_last_city= $('#time_id').val();     
var stud_last_state= $('#date_id').val();     
var stud_last_country= $('#message').val();  
  $.ajax({
    type:"POST",

  // alert('A1'+stud_last_stand+'A2'+stud_last_board+'city'+stud_last_perc+'st'+stud_last_school+'pinc'+stud_last_city+'resc'+stud_last_state+'hidd'+stud_last_country);
    url:'sending_mail.php',
    data:{
    name:stud_last_stand,
    email:stud_last_board,
    phone:stud_last_perc,
    add:stud_last_school,
    time:stud_last_city, 
    date:stud_last_state,                  
    message:stud_last_country

    },
    
    success:function(response){
    alert(response);
    // alert("Message has been sent");
    
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) { 
        alert("Message has been sent" );  
    }       
  });
});
  
</script>
<script src="assets/jquery.js"></script>
       
        <div class="modal-footer">
         
          
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>

    </div>
  </div>
 </div> 




