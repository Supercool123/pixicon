<?php
include('db_config.php');
new Database();

$username= $_POST['user'];
$password= $_POST['pass'];

/*$username = stripcslashes($username);
$password = stripcslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);
*/
if(!empty($username) && !empty($password)){
$result1="select * from users where username = '".$username."' and password='".$password."'";
header('Location:index.php');
//echo $result1;
$fetch_data  = mysql_query($result1) or die(mysql_error());

while($row = mysql_fetch_array($fetch_data)){
// echo $row[0];
   header('Location:home.html');

}

/*echo $result1;
$result = mysql_query($result1) or die(mysql_error());
$row = mysql_fetch_row($result1);
//print_r($_POST);
print_r("UN-> ". $row['username'] );
print_r("pswrdS-> ". $row['password'] );
if ($row['username']==$username&&$row['password']==$password) {

   //header('Location:home.html');
echo "hi";
}
else{
  // header('Location:index.php');

}*/
}
else{
  header('Location:index.php');
	
}
?>