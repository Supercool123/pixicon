<?php
include('db_config.php');
// include('connection.php');
New Database();
print_r($_POST);
$rate_makeup_item1 = $_POST['rate_makeup_item1'];
$rate_makeup_item2 = $_POST['rate_makeup_item2'];
$rate_makeup_item3 = $_POST['rate_makeup_item3'];
$rate_makeup_item4 = $_POST['rate_makeup_item4'];
$rate_makeup_item5 = $_POST['rate_makeup_item5'];
$rate_makeup_item6 = $_POST['rate_makeup_item6'];
$rate_makeup_item7 = $_POST['rate_makeup_item7'];

/*Query to insert packages details in Database*/
$insert_rate_details = 'INSERT INTO rate_makeup(`rate_makeup_item1`,`rate_makeup_item2`,`rate_makeup_item3`,`rate_makeup_item4`,`rate_makeup_item5`,`rate_makeup_item6`,`rate_makeup_item7`) VALUES ("'.$rate_makeup_item1.'","'.$rate_makeup_item2.'","'.$rate_makeup_item3.'","'.$rate_makeup_item4.'","'.$rate_makeup_item5.'","'.$rate_makeup_item6.'","'.$rate_makeup_item7.'") ';
// echo $insert_packages_details;
$inserted = mysql_query($insert_rate_details);
header('Location:rate_card2.html');
/*$test = "SELECT * FROM ";
$fetch_data  = mysql_query($test) or die(mysql_error());
while($row = mysql_fetch_array($fetch_data)){
echo $row['packages_name'];
}*/
?>