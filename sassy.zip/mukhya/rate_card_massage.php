<?php
include('db_config.php');
// include('connection.php');
New Database();
print_r($_POST);
$rate_massage1 = $_POST['rate_massage1'];
$rate_massage2 = $_POST['rate_massage2'];
$rate_massage3 = $_POST['rate_massage3'];
$rate_massage4 = $_POST['rate_massage4'];
$rate_massage5 = $_POST['rate_massage5'];
$rate_massage6 = $_POST['rate_massage6'];
$rate_massage7 = $_POST['rate_massage7'];
$rate_massage8 = $_POST['rate_massage8'];
$rate_massage9 = $_POST['rate_massage9'];
$rate_massage10 = $_POST['rate_massage10'];
$rate_massage11 = $_POST['rate_massage11'];
$rate_massage12 = $_POST['rate_massage12'];
$rate_massage13 = $_POST['rate_massage13'];
$rate_massage14 = $_POST['rate_massage14'];



$insert_rate_massage_details = 'INSERT INTO rate_massage(`rate_massage1`,`rate_massage2`,`rate_massage3`,`rate_massage4`,`rate_massage5`,`rate_massage6`,`rate_massage7`,`rate_massage8`,`rate_massage9`,`rate_massage10`,`rate_massage11`,`rate_massage12`,`rate_massage13`,`rate_massage14`) VALUES ("'.$rate_massage1.'","'.$rate_massage2.'","'.$rate_massage3.'","'.$rate_massage4.'","'.$rate_massage5.'","'.$rate_massage6.'","'.$rate_massage7.'","'.$rate_massage8.'","'.$rate_massage9.'","'.$rate_massage10.'","'.$rate_massage11.'","'.$rate_massage12.'","'.$rate_massage13.'","'.$rate_massage14.'") ';
// echo $insert_packages_details;
$inserted = mysql_query($insert_rate_massage_details);
header('Location:rate_card.html');
/*$test = "SELECT * FROM ";
$fetch_data  = mysql_query($test) or die(mysql_error());
while($row = mysql_fetch_array($fetch_data)){
echo $row['packages_name'];
}*/
?>