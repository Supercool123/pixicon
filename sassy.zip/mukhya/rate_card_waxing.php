<?php
include('db_config.php');
// include('connection.php');
New Database();
print_r($_POST);
$rate_waxing_item1 = $_POST['rate_waxing_item1'];
$rate_waxing_item2 = $_POST['rate_waxing_item2'];
$rate_waxing_item3 = $_POST['rate_waxing_item3'];
$rate_waxing_item4 = $_POST['rate_waxing_item4'];
$rate_waxing_item5 = $_POST['rate_waxing_item5'];
$rate_waxing_item6 = $_POST['rate_waxing_item6'];
$rate_waxing_item7 = $_POST['rate_waxing_item7'];
$rate_waxing_item8 = $_POST['rate_waxing_item8'];
$rate_waxing_item9 = $_POST['rate_waxing_item9'];
$rate_waxing_item10 = $_POST['rate_waxing_item10'];
$rate_waxing_item11 = $_POST['rate_waxing_item11'];
$rate_waxing_item12 = $_POST['rate_waxing_item12'];
$rate_waxing_item13 = $_POST['rate_waxing_item13'];
$rate_waxing_item14 = $_POST['rate_waxing_item14'];
$rate_waxing_item15 = $_POST['rate_waxing_item15'];
$rate_waxing_item16 = $_POST['rate_waxing_item16'];
$rate_waxing_item17 = $_POST['rate_waxing_item17'];
$rate_waxing_item18 = $_POST['rate_waxing_item18'];
$rate_waxing_item19 = $_POST['rate_waxing_item19'];
$rate_waxing_item20 = $_POST['rate_waxing_item20'];
$rate_waxing_item21 = $_POST['rate_waxing_item21'];
$rate_waxing_item22 = $_POST['rate_waxing_item22'];
$rate_waxing_item23 = $_POST['rate_waxing_item23'];
$rate_waxing_item24 = $_POST['rate_waxing_item24'];
$rate_waxing_item25 = $_POST['rate_waxing_item25'];
$rate_waxing_item26 = $_POST['rate_waxing_item26'];
$rate_waxing_item27 = $_POST['rate_waxing_item27'];
$rate_waxing_item28 = $_POST['rate_waxing_item28'];
$rate_waxing_item29 = $_POST['rate_waxing_item29'];
$rate_waxing_item30 = $_POST['rate_waxing_item30'];
$rate_waxing_item31 = $_POST['rate_waxing_item31'];
$rate_waxing_item32 = $_POST['rate_waxing_item32'];
$rate_waxing_item33 = $_POST['rate_waxing_item33'];
$rate_waxing_item34 = $_POST['rate_waxing_item34'];
$rate_waxing_item35 = $_POST['rate_waxing_item35'];
$rate_waxing_item36 = $_POST['rate_waxing_item36'];
$rate_waxing_item37 = $_POST['rate_waxing_item37'];
$rate_waxing_item38 = $_POST['rate_waxing_item38'];
$rate_waxing_item39 = $_POST['rate_waxing_item39'];
$rate_waxing_item40 = $_POST['rate_waxing_item40'];
$rate_waxing_item41 = $_POST['rate_waxing_item41'];
$rate_waxing_item42 = $_POST['rate_waxing_item42'];


$insert_rate_waxing_details = 'INSERT INTO rate_waxing(`rate_waxing_item1`,`rate_waxing_item2`,`rate_waxing_item3`,`rate_waxing_item4`,`rate_waxing_item5`,`rate_waxing_item6`,`rate_waxing_item7`,`rate_waxing_item8`,`rate_waxing_item9`,`rate_waxing_item10`,`rate_waxing_item11`,`rate_waxing_item12`,`rate_waxing_item13`,`rate_waxing_item14`,`rate_waxing_item15`,`rate_waxing_item16`,`rate_waxing_item17`,`rate_waxing_item18`,`rate_waxing_item19`,`rate_waxing_item20`,`rate_waxing_item21`,`rate_waxing_item22`,`rate_waxing_item23`,`rate_waxing_item24`,`rate_waxing_item25`,`rate_waxing_item26`,`rate_waxing_item27`,`rate_waxing_item28`,`rate_waxing_item29`,`rate_waxing_item30`,`rate_waxing_item31`,`rate_waxing_item32`,`rate_waxing_item33`,`rate_waxing_item34`,`rate_waxing_item35`,`rate_waxing_item36`,`rate_waxing_item37`,`rate_waxing_item38`,`rate_waxing_item39`,`rate_waxing_item40`,`rate_waxing_item41`,`rate_waxing_item42`) VALUES ("'.$rate_waxing_item1.'","'.$rate_waxing_item2.'","'.$rate_waxing_item3.'","'.$rate_waxing_item4.'","'.$rate_waxing_item5.'","'.$rate_waxing_item6.'","'.$rate_waxing_item7.'","'.$rate_waxing_item8.'","'.$rate_waxing_item9.'","'.$rate_waxing_item10.'","'.$rate_waxing_item11.'","'.$rate_waxing_item12.'","'.$rate_waxing_item13.'","'.$rate_waxing_item14.'","'.$rate_waxing_item15.'","'.$rate_waxing_item16.'","'.$rate_waxing_item17.'","'.$rate_waxing_item18.'","'.$rate_waxing_item19.'","'.$rate_waxing_item20.'","'.$rate_waxing_item21.'","'.$rate_waxing_item22.'","'.$rate_waxing_item23.'","'.$rate_waxing_item24.'","'.$rate_waxing_item25.'","'.$rate_waxing_item26.'","'.$rate_waxing_item27.'","'.$rate_waxing_item28.'","'.$rate_waxing_item29.'","'.$rate_waxing_item30.'","'.$rate_waxing_item31.'","'.$rate_waxing_item32.'","'.$rate_waxing_item33.'","'.$rate_waxing_item34.'","'.$rate_waxing_item35.'","'.$rate_waxing_item36.'","'.$rate_waxing_item37.'","'.$rate_waxing_item38.'","'.$rate_waxing_item39.'","'.$rate_waxing_item40.'","'.$rate_waxing_item41.'","'.$rate_waxing_item42.'") ';
// echo $insert_packages_details;
$inserted = mysql_query($insert_rate_waxing_details);
header('Location:rate_card2.html');
/*$test = "SELECT * FROM ";
$fetch_data  = mysql_query($test) or die(mysql_error());
while($row = mysql_fetch_array($fetch_data)){
echo $row['packages_name'];
}*/
?>