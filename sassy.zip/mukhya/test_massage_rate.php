 <?php
include('db_config.php');
new Database();
$test = "SELECT * FROM rate_massage order by 1  DESC  LIMIT 0,1";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>




 <table class="table table-striped" style="font-weight: bold;">
      <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12 col-centered">
    <thead>
      <tr>
        <th style="background-color:#000000;color:#fff"><h4>Massage</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Massage</td>
        <?php while($row = mysql_fetch_array($fetch_data)):?>
        <td>&#8377;<?php echo $row['rate_massage1'];?></td>
        
      </tr>
      <tr>
        <td>Harbal Head Massage</td>
        <td>&#8377;<?php echo $row['rate_massage2'];?></td>
       
      </tr>
      <tr>
        <td>Head Massage</td>
        <td>&#8377;<?php echo $row['rate_massage3'];?></td>
      </tr>
      <tr>
        <td>Back Massage</td>
       <td>&#8377;<?php echo $row['rate_massage4'];?></td>
        
      </tr>
      <tr>
        <td>Foot Massage</td>
        <td>&#8377;<?php echo $row['rate_massage5'];?></td>
      </tr>
      <tr>
        <td>Normal Body Massage</td>
        <td>&#8377;<?php echo $row['rate_massage6'];?></td>
      </tr>
      <tr>
        <td>Swedish Body Massage</td>
        <td>&#8377;<?php echo $row['rate_massage7'];?></td>
      </tr>
      <tr>
        <td>Body Polising</td>
        <td>&#8377;<?php echo $row['rate_massage8'];?></td>
      </tr>
      <tr>
        <td>Body Scrub</td>
        <td>&#8377;<?php echo $row['rate_massage9'];?></td>
      </tr>
      <tr>
        <td>Body Packs N Wraps</td>
        <td>&#8377;<?php echo $row['rate_massage10'];?></td>
      </tr>
        <tr>
        <td>Body Polish</td>
        <td>&#8377;<?php echo $row['rate_massage11'];?></td>
      </tr>
            <tr>
        <td>Back Polish</td>
        <td>&#8377;<?php echo $row['rate_massage12'];?></td>
      </tr>
            <tr>
        <td>Hands Polish</td>
        <td>&#8377;<?php echo $row['rate_massage13'];?></td>
      </tr>
            <tr>
        <td>Legs Polish</td>
        <td>&#8377;<?php echo $row['rate_massage14'];?></td>
      </tr>
      <?php endwhile?>
      </tbody>
      </div>
  </table>