<?php
require("PHPMailer_5.2.0/class.phpmailer.php");
$mail = new PHPMailer();
$mail->IsSMTP();                                      // set mailer to use SMTP
$mail->Host = "mx1.2freehosting.com";  // specify main and backup server
$mail->SMTPAuth = true;     // turn on SMTP authentication

$mail->Username = "sassybabu@sassy.3eeweb.com";  // SMTP username
$mail->Password = "sassy123"; // SMTP password
$mail->Port = "587";
//$mail->SMTPSecure = 'tls';
$mail->From = "sassysalon.in";
$mail->FromName = "Booking";
$mail->AddAddress("sassyhomesalon@gmail.com");
$mail->AddReplyTo("info@example.com", "Information");

$mail->WordWrap = 550;                                 // set word wrap to 50 characters

$mail->IsHTML(true);                                  // set email format to HTML


$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['add'];
$time_2 = $_POST['time'];
$date_2 = $_POST['date'];
$message = $_POST['message'];
if(!empty($name) && !empty($email) && !empty($phone) && !empty($address) && !empty($time_2) && !empty($date_2) && !empty($message))
{

		echo "Message has been sent";
		if($message!="" && !empty($name)){

	$mail->Subject = "New Order";
	$mail->Body    = 'Name:'.$name.'<br>
	                  email:'.$email.'<br>
	                  phone:'.$phone.'<br>
	                  address:'.$address.'<br>
	                  time:'.$time_2.'<br>
	                  date:'.$date_2.'<br>
	                  message:'.$message.'<br>';
	$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

	if(!$mail->Send())
	{
	   echo "Message could not be sent. <p>";
	   echo "Mailer Error: " . $mail->ErrorInfo;
	   exit;
	}
}
	
}
else
{
	echo "Please enter all mandatory information";
}
?>
