<?php
require("PHPMailer_5.2.0/class.phpmailer.php");
print_r($_POST);
$mail = new PHPMailer();
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];

$message = $_POST['message'];



$mail->IsSMTP();                                      // set mailer to use SMTP
$mail->Host = "mx1.2freehosting.com";  // specify main and backup server
$mail->SMTPAuth = true;     // turn on SMTP authentication

$mail->Username = "sassybabu@sassy.3eeweb.com";  // SMTP username
$mail->Password = "sassy123"; // SMTP password
$mail->Port = "587";
//$mail->SMTPSecure = 'tls';
$mail->From = "sassysalon.in";
$mail->FromName = "MESSAGE";
$mail->AddAddress("sassyhomesalon@gmail.com");
$mail->AddReplyTo("info@example.com", "Information");

$mail->WordWrap = 50;                                 // set word wrap to 50 characters

$mail->IsHTML(true);                                  // set email format to HTML
if(!empty($name) && !empty($email) && !empty($phone)  && !empty($message))
{
$mail->Subject = "New Feedback";
$mail->Body    = 'Name:'.$name.'<br>
                  email:'.$email.'<br>
                  phone:'.$phone.'<br>
                  message:'.$message.'<br>';
$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->Send())
{
   echo "Message could not be sent. <p>";
   echo "Mailer Error: " . $mail->ErrorInfo;
   exit;
}

echo "Message has been sent";
}
else
{
	echo "string";
}
?>
