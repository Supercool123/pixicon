<?php

new Database();
$test = "SELECT * FROM rate_waxing order by 1  DESC  LIMIT 0,1";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>


<table class="table " style="font-weight: bold;background-color:(94,94,94,0.83);">
          <div class="col-xs-3 col-sm-6 col-md-12 col-lg-12 col-centered">
    <thead>
      <tr>
        <th style="background-color:#000000; color:#fff"><h4>Waxing</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Normal</h4></th><th style="background-color:#000000;color:#fff"><h4>Chocolate</h4></th><th style="background-color:#000000;color:#fff"><h4>Rica</h4></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Upper Lip</td>
         <?php while($row = mysql_fetch_array($fetch_data)):?>
        <td>&#8377;<?php echo $row['rate_waxing_item1'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item2'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item3'];?></td>
      </tr>
      <tr>
        <td>Chin</td>
        <td>&#8377;<?php echo $row['rate_waxing_item4'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item5'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item6'];?></td>
      </tr>
      <tr>
        <td>Side Locks/ Jawline</td>
        <td>&#8377;<?php echo $row['rate_waxing_item7'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item8'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item9'];?></td>
      </tr>
      <tr>
        <td>Underarms</td>
        <td>&#8377;<?php echo $row['rate_waxing_item10'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item11'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item12'];?></td>
      </tr>
      <tr>
        <td>Full Face</td>
        <td>&#8377;<?php echo $row['rate_waxing_item13'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item14'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item15'];?></td>
      </tr>
      <tr>
        <td>Full Hands</td>
        <td>&#8377;<?php echo $row['rate_waxing_item16'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item17'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item18'];?></td>
      </tr>
      <tr>
        <td>Half Legs</td>
        <td>&#8377;<?php echo $row['rate_waxing_item19'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item20'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item21'];?></td>
      </tr>
      <tr>
        <td>Full Legs</td>
        <td>&#8377;<?php echo $row['rate_waxing_item22'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item23'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item24'];?></td>
      </tr>
      <tr>
        <td>Stomach</td>
        <td>&#8377;<?php echo $row['rate_waxing_item25'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item26'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item27'];?></td>
      </tr>
      <tr>
        <td>Half Front/ Back</td>
        <td>&#8377;<?php echo $row['rate_waxing_item28'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item29'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item30'];?></td>
      </tr>
      <tr>
        <td>Full Front/ Back</td>
        <td>&#8377;<?php echo $row['rate_waxing_item31'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item32'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item33'];?></td>
      </tr>
      <tr>
        <td>Bikini Line</td>
        <td>&#8377;<?php echo $row['rate_waxing_item34'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item35'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item36'];?></td>
      </tr>
      <tr>
        <td>Full Bikini Wax</td>
        <td>&#8377;<?php echo $row['rate_waxing_item37'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item38'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item39'];?></td>
      </tr>
      <tr>
        <td>Full Body</td>
        <td>&#8377;<?php echo $row['rate_waxing_item40'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item41'];?></td>
        <td>&#8377;<?php echo $row['rate_waxing_item42'];?></td>
     
      </tr>
      </tbody>
       <?php endwhile ?>
      </div>
  </table>