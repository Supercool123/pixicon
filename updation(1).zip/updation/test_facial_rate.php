<?php

new Database();
$test = "SELECT * FROM rate_facial order by 1  DESC  LIMIT 0,1";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>
<script type="text/javascript">
  <!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-TGZJSH"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TGZJSH');</script>
<!-- End Google Tag Manager -->
</script>

  

   
<table class="table " style="color: #fff;font-weight: 100;">
          <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12 col-centered">
    <thead>
      <tr>
        <th style="background-color:#000000;color:#fff"><h4>Facial</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Regular Clean-Up</td>
        <?php while($row = mysql_fetch_array($fetch_data)):?>
        <td>&#8377;<?php echo $row['rate_facial_item1'];?></td>
       
      </tr>
      <tr>
        <td>Insta Clear Clean-Up</td>
        <td>&#8377;<?php echo $row['rate_facial_item2'];?></td>
       
      </tr>
      <tr>
        <td>Herbal Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item3'];?></td>
      </tr>
      <tr>
        <td>VLCC Fruit Facial</td>
       <td>&#8377;<?php echo $row['rate_facial_item4'];?></td>
        
      </tr>
      <tr>
        <td>VLCC Insta Glow Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item5'];?></td>
      </tr>
      <tr>
        <td>VLCC Silver Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item6'];?></td>
      </tr>
      <tr>
        <td>VLCC Anti-Tan Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item7'];?></td>
      </tr>
      <tr>
        <td>VLCC Party Glow Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item8'];?></td>
      </tr>
      <tr>
        <td>VLCC Skin Tightening Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item9'];?></td>
      </tr>
      <tr>
        <td>VLCC Pearl Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item10'];?></td>
      </tr>
        <tr>
        <td>VLCC Gold Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item11'];?></td>
      </tr>
            <tr>
        <td>VLCC Diamond Facial</td>
        <td>&#8377;<?php echo $row['rate_facial_item12'];?></td>
      </tr>
            <tr>
        <td>Cheryl's GloVite Facial (Fairness)</td>
        <td>&#8377;<?php echo $row['rate_facial_item13'];?></td>
      </tr>
            <tr>
        <td>Cheryl's TanClear Facial (Anti Pigmentation)</td>
        <td>&#8377;<?php echo $row['rate_facial_item14'];?></td>
      </tr>
      <tr>
        <td>Cheryl's OxyBlast Facial (Radiance)</td>
        <td>&#8377;<?php echo $row['rate_facial_item15'];?></td>
      </tr>
      
      <tr>
        <td>Cheryl's VitaLift Facial (Anti Ageing)</td>
        <td>&#8377;<?php echo $row['rate_facial_item16'];?></td>
      </tr>
      <tr>
        <td>Cheryl's SensiGlow Facial (Sensitive Skin)</td>
        <td>&#8377;<?php echo $row['rate_facial_item17'];?></td>
      </tr>
      <tr>
        <td>Cheryl's ClariGlow Facial (Oily Skin)</td>
        <td>&#8377;<?php echo $row['rate_facial_item18'];?></td>
      </tr>
      <tr>
        <td>Cheryl's O2C2 Facial (Radiance)</td>
        <td>&#8377;<?php echo $row['rate_facial_item19'];?></td>
      </tr>
      <tr>
        <td>Cheryl's Hydramoist Facial </td>
        <td>&#8377;<?php echo $row['rate_facial_item20'];?></td>
      </tr>
       
<th style="background-color:#000000;color:#fff"><h4>Bleach</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>

        <tr>
        <td>Chin</td>
        <td>&#8377;<?php echo $row['rate_facial_item21'];?></td>
      </tr>
      <tr>
        <td>Upper Lip</td>
        <td>&#8377;<?php echo $row['rate_facial_item22'];?></td>
      </tr>
      <tr>
        <td>Under Arms</td>
        <td>&#8377;<?php echo $row['rate_facial_item23'];?></td>
      </tr>
      <tr>
        <td>Face & Neck</td>
        <td>&#8377;<?php echo $row['rate_facial_item24'];?></td>
      </tr>
      <tr>
        <td>Face, Neck & Blouse Line</td>
        <td>&#8377;<?php echo $row['rate_facial_item25'];?></td>
      </tr>
      <tr>
        <td>Full Hands</td>
        <td>&#8377;<?php echo $row['rate_facial_item26'];?></td>
      </tr>
      <tr>
        <td>Full Legs</td>
        <td>&#8377;<?php echo $row['rate_facial_item27'];?></td>
      </tr>
      <tr>
        <td>Full Back</td>
        <td>&#8377;<?php echo $row['rate_facial_item28'];?></td>
      </tr>
      <tr>
        <td>Full Front</td>
        <td>&#8377;<?php echo $row['rate_facial_item29'];?></td>
      </tr>
      <tr>
        <td>Full Body</td>
        <td>&#8377;<?php echo $row['rate_facial_item30'];?></td>
      </tr>

      
      <th style="background-color:#000000;color:#fff"><h4>Threading</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      <tr>
        <td>Lower Lip</td>
        <td>&#8377;<?php echo $row['rate_facial_item31'];?></td>
      </tr>
      <tr>
        <td>Forehead</td>
        <td>&#8377;<?php echo $row['rate_facial_item32'];?></td>
      </tr>
      <tr>
        <td>Eyebrows</td>
        <td>&#8377;<?php echo $row['rate_facial_item33'];?></td>
      </tr>
      <tr>
        <td>Upper Lip</td>
        <td>&#8377;<?php echo $row['rate_facial_item34'];?></td>
      </tr>
      <tr>
        <td>Chin</td>
        <td>&#8377;<?php echo $row['rate_facial_item35'];?></td>
      </tr>
      <tr>
        <td>Sides & Jawline</td>
        <td>&#8377;<?php echo $row['rate_facial_item36'];?></td>
      </tr>
      <tr>
        <td>Full Face</td>
        <td>&#8377;<?php echo $row['rate_facial_item37'];?></td>
        <?php endwhile?>
      </tr>
      </tbody>
      </div>
  </table>