
<?php

new Database();
$test = "SELECT * FROM rate_makeup order by 1  DESC  LIMIT 0,1";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>
<script type="text/javascript">
  <!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-TGZJSH"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TGZJSH');</script>
<!-- End Google Tag Manager -->
</script>

<table class="table " style="font-weight: bold;color:#fff">
          <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12 col-centered">
    <thead>
      <tr>
        <th style="background-color:#000000;color:#fff"><h4>Make Up</h4></th>        <th style="background-color:#000000;color:#fff;padding-left:25%"><h4>Rate</h4></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Saree Draping</td>
        <?php while($row = mysql_fetch_array($fetch_data)):?>
        <td style="padding-left:25%">&#8377;<?php echo $row['rate_makeup_item1'];?></td>
        
      </tr>
      <tr>
        <td>Normal Hair Do</td>
        <td style="padding-left:25%">&#8377;<?php echo $row['rate_makeup_item2'];?></td>
       
      </tr>
      <tr>
        <td>Basic make up</td>
        <td style="padding-left:25%">&#8377;<?php echo $row['rate_makeup_item3'];?></td></td>
      </tr>
      <tr>
        <td>Party Makeup</td>
       <td style="padding-left:25%">&#8377;<?php echo $row['rate_makeup_item4'];?></td>
        
      </tr>
      <tr>
        <td>Style Hair Do</td>
        <td style="padding-left:25%">&#8377;<?php echo $row['rate_makeup_item5'];?></td>
      </tr>
      <tr>
        <td>Bridal Hair Do</td>
        <td style="padding-left:25%">&#8377;<?php echo $row['rate_makeup_item6'];?></td>
      </tr>
      <tr>
        <td>Bridal Makeup</td>
        <td style="padding-left:25%">&#8377;<?php echo $row['rate_makeup_item7'];?></td>
      <?php endwhile ?>
      </tr>
      </tbody>
      </div>
  </table>