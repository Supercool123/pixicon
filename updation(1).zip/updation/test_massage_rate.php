<?php

new Database();
$test = "SELECT * FROM rate_massage order by 1  DESC  LIMIT 0,1";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>



<script type="text/javascript">
  <!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-TGZJSH"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TGZJSH');</script>
<!-- End Google Tag Manager -->
</script>
 <table class="table" style="color:#fff;font-weight: bold;">
      <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12 col-centered">
    <thead>
      <tr>
        <th style="background-color:#000000;color:#fff"><h4>Massage</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      </tr>
    </thead>
    <tbody>
      <tr>
      <?php while($row = mysql_fetch_array($fetch_data)):?>
        <td>Dry Head Massage</td>
        <td>&#8377;<?php echo $row['rate_massage2'];?></td>
       
      </tr>
      <tr>
        <td>Oil Head Massage</td>
        <td>&#8377;<?php echo $row['rate_massage3'];?></td>
      </tr>
      <tr>
        <td>Herbal Oil Head Massage</td>
        <td>&#8377;<?php echo $row['rate_massage8'];?></td>
      </tr>
      <tr>
        <td>Back Massage</td>
       <td>&#8377;<?php echo $row['rate_massage4'];?></td>
        
      </tr>
      <tr>
        <td>Foot Massage</td>
        <td>&#8377;<?php echo $row['rate_massage5'];?></td>
      </tr>
      <tr>
        <td>Normal Body Massage</td>
        <td>&#8377;<?php echo $row['rate_massage6'];?></td>
      </tr>
      <tr>
        <td>Swedish Body Massage</td>
        <td>&#8377;<?php echo $row['rate_massage7'];?></td>
      </tr>
      <tr>
        <td>Prenatal Massage</td>
        
        <td>&#8377;<?php echo $row['rate_massage1'];?></td>
      </tr>
      <th style="background-color:#000000;color:#fff"><h4>Body Polishing</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      <tr>
        <td>Back Polish</td>
        <td>&#8377;<?php echo $row['rate_massage9'];?></td>
      </tr>
      <tr>
        <td>Hands Polish</td>
        <td>&#8377;<?php echo $row['rate_massage10'];?></td>
      </tr>
        <tr>
        <td>Legs Polish</td>
        <td>&#8377;<?php echo $row['rate_massage11'];?></td>
      </tr>
            <tr>
        <td>Body Scrub</td>
        <td>&#8377;<?php echo $row['rate_massage12'];?></td>
      </tr>
            <tr>
        <td>Body Packs N Wraps</td>
        <td>&#8377;<?php echo $row['rate_massage13'];?></td>
      </tr>
            <tr>
        <td>Body Polishing</td>
        <td>&#8377;<?php echo $row['rate_massage14'];?></td>
      </tr>
      <?php endwhile?>
      </tbody>
      </div>
  </table>