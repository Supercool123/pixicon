
place these files in assets directory inside html directory

1)jquery-1.8.3.min.js
2)bootstrap.min.js
3)bootstrap-datetimepicker.fr.js
4)bootstrap-datetimepicker.js
5)bootstrap-datetimepicker.min.css

and move rest of them in html directory