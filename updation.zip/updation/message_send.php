<?php 
//include('db.php');
// session_start();
// echo "Hello PK";
require("PHPMailer_5.2.0/class.phpmailer.php");
$mail = new PHPMailer();
$mail->IsSMTP();                                      // set mailer to use SMTP
$mail->Host = "mx1.2freehosting.com";  // specify main and backup server
$mail->SMTPAuth = true;     // turn on SMTP authentication

$mail->Username = "sassybabu@sassy.3eeweb.com";  // SMTP username
$mail->Password = "sassy123"; // SMTP password
$mail->Port = "587";
$mail->AddAddress("sassyhomesalon@gmail.com");
$mail->Subject = "New Booking";
$mail->From = "sassysalon.in";
$mail->FromName = "BOOKING";
$d_t=$_POST['d_t'];
$con_name= $_POST['con_name'];
$con_mbl=$_POST['con_mbl'];
$con_company=$_POST['con_company'];
$con_int_tender=$_POST['con_int_tender'];
$con_msg=$_POST['con_msg']; 
// error_reporting(1);
// if(isset($_REQUEST))
// extract($_REQUEST);
// print_r($_REQUEST);

// $con_mbl = '0123456789';  

// if (!preg_match('/^0\d{10}$/', $con_mbl) )

	if(!empty($con_name) && !empty($con_mbl) && !empty($con_company) && !empty($con_int_tender) && !empty($con_msg) && !empty($d_t))
	{


		if (preg_match('/^\+?([0-9]{1,4})\)?[-. ]?([0-9]{9})$/', $con_mbl) && !(count(array_filter(str_split($con_mbl),'is_numeric'))>10)  )
		{
			if (!filter_var($con_company, FILTER_VALIDATE_EMAIL)) 
			{
			echo "Enter Valid E-mail";
		      }else{
		//print count(array_filter(str_split($con_mbl),'is_numeric'));
			// $query_school_fees_structure = "INSERT INTO message_user 
			// 								SET con_name = '$con_name',con_mbl = '$con_mbl',con_company = '$con_company',	con_int_tender = '$con_int_tender',con_msg = '$con_msg'";

		    $mail_message = "Name: ".$con_name."\nMobile No: ".$con_mbl."\nE-mail: ".$con_company."\nAddress: ".$con_int_tender."\nDate:".$d_t."\nServices: ".$con_msg ; 
			// echo $query_school_fees_structure;	

			/*mysql_query($query_school_fees_structure);*/
			// print_r($mail_message);	
			$newtext = wordwrap($mail_message, 70);
		    // mail("contact@tenderkhojo.com", "Query regards", $newtext);
		    $mail->Body = $newtext;
		    echo "succ";
		    $mail->Send();

			}

		}

		else if((count(array_filter(str_split($con_mbl),'is_numeric'))>10))

		{
		$mbcount = count(array_filter(str_split($con_mbl),'is_numeric'));

		echo "You entered ".$mbcount." digit. Please enter 10 digit number.";

		}
		else if((count(array_filter(str_split($con_mbl),'is_numeric'))<10) || preg_match('-',$con_mbl)){
			$con_mbl_new = ltrim($con_mbl, '0');
			// echo 'MBL'. $con_mbl_new .'/n';
			// echo '-Rem'.preg_replace('/-+/','',$con_mbl_new) .'/n';
			// $phone_no = preg_replace('/-+/','',$con_mbl_new); 
		// echo "For telephone: ".$con_mbl." ~ ".preg_replace('/-+/','',$con_mbl_new)."".str_pad($input,  1, "___")."\n";
		$mbcount = count(array_filter(str_split($con_mbl),'is_numeric'));
		 echo "You entered ".$mbcount." digit. Please enter 10 digit number.";
		}

	 

	}
	else
	{
		// $con_mbl_new = ltrim($con_mbl, '0');
		// echo "For telephone: ".$con_mbl." ~ ".preg_replace('/-+/','',$con_mbl_new)."\n";
		// echo "Please Enter a valid phone number";
		echo "All Fields Are Mandatory";
	}
// ".str_pad($input,  1, "___")."
?>