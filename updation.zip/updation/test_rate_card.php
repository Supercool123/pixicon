<?php

new Database();
$test = "SELECT * FROM rate_hair order by 1  DESC  LIMIT 0,1";
$fetch_data  = mysql_query($test) or die(mysql_error());

?>


<script type="text/javascript">
  <!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-TGZJSH"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TGZJSH');</script>
<!-- End Google Tag Manager -->
</script>


<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<table class="table " style="font-weight: bold;color:#fff">
           <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12 col-centered">
     <thead>
      <tr>
        <th style="background-color:#000000;color:#fff"><h4>Hair Care Styling</h4></th>        <th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Blow-Dry Upto Shoulder</td>
         <?php while($row = mysql_fetch_array($fetch_data)):?>
        <td>&#8377;<?php echo $row['rate_item1'];?></td>
        
      </tr>
      <tr>
        <td>Blow-Dry Below Shoulder</td>
        <td>&#8377;<?php echo $row['rate_item2'];?></td>
       
      </tr>
      <tr>
        <td>Blow-Dry Upto Waist</td>
        <td>&#8377;<?php echo $row['rate_item3'];?></td>
      </tr>
      <tr>
        <td>Ironing- Upto Shoulder</td>
       <td>&#8377;<?php echo $row['rate_item4'];?></td>
        
      </tr>
      <tr>
        <td>Ironing- Below Shoulder</td>
        <td>&#8377;<?php echo $row['rate_item5'];?></td>
      </tr>
      <tr>
       
      <tr>
        <td>Ironing- Upto waist</td>
        <td>&#8377;<?php echo $row['rate_item6'];?></td>
      </tr>
      <tr>
        <td>Curling(Medium Hair)</td>
        <td>&#8377;<?php echo $row['rate_item7'];?></td>
      </tr>
      <tr>
        <td>Curling(Long hair)</td>
        <td>&#8377;<?php echo $row['rate_item8'];?></td>
      </tr>
      
      <th style="background-color:#000000;color:#fff"><h4>Hair spa/Treatment </h4></th><th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      <tr>
        <td>Upto Shoulder</td>
        <td>&#8377;<?php echo $row['rate_item9'];?></td>
      </tr>
        <tr>
        <td>Below Shoulder</td>
        <td>&#8377;<?php echo $row['rate_item10'];?></td>
      </tr>
            <tr>
        <td>Below Waist</td>
        <td>&#8377;<?php echo $row['rate_item11'];?></td>
      </tr>
            <tr>
        <td>Anti Hairfall Treatment</td>
        <td>&#8377;<?php echo $row['rate_item12'];?></td>
      </tr>
            <tr>
        <td>Anti Dandruff Treatment</td>
        <td>&#8377;<?php echo $row['rate_item13'];?></td>
      </tr>
      <tr>
        <td>Protein Booster(Add-On)</td>
        <td>&#8377;<?php echo $row['rate_item14'];?></td>
      </tr>

<th style="background-color:#000000;color:#fff"><h4>Hair Cut</h4></th><th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
      <tr>
        <td>Blow Dry/Hair setting</td>
        <td>&#8377;<?php echo $row['rate_item15'];?></td>
      </tr>
      <tr>
        <td>Kids</td>
        <td>&#8377;<?php echo $row['rate_item16'];?></td>
      </tr>
      <tr>
        <td>Straight</td>
        <td>&#8377;<?php echo $row['rate_item17'];?></td>
      </tr>
      <tr>
        <td>Trim</td>
        <td>&#8377;<?php echo $row['rate_item18'];?></td>
      </tr>
      <tr>
        <td>U</td>
        <td>&#8377;<?php echo $row['rate_item19'];?></td>
      </tr>
      <tr>
        <td>Deep U</td>
        <td>&#8377;<?php echo $row['rate_item20'];?></td>
      </tr>
      <tr>
        <td>Step</td>
        <td>&#8377;<?php echo $row['rate_item35'];?></td>
      </tr>
        <tr>
        <td>Layer</td>
        <td>&#8377;<?php echo $row['rate_item21'];?></td>
      </tr>
      <tr>
        <td>Re-Styling</td>
        <td>&#8377;<?php echo $row['rate_item22'];?></td>
      </tr>
      <tr>
        <td>Feather</td>
        <td>&#8377;<?php echo $row['rate_item23'];?></td>
      </tr>
      <tr>
        <td>Advance styling</td>
        <td>&#8377;<?php echo $row['rate_item24'];?></td>
      </tr>
      
     <th style="background-color:#000000;color:#fff"> <h4>Hair Color</h4></th><th style="background-color:#000000;color:#fff"><h4>Rate</h4></th>
     
     
      <tr>
        <td>Henna Application(Customer Color)</td>
        <td>&#8377;<?php echo $row['rate_item25'];?></td>
      </tr>
      <tr>
        <td>Root Touch-Up(Customer Color)</td>
        <td>&#8377;<?php echo $row['rate_item26'];?></td>
      </tr>
      <tr>
        <td>Global Color(Customer Color)</td>
        <td>&#8377;<?php echo $row['rate_item27'];?></td>
      </tr>
      <tr>
        <td>Root Touch-Up(Sassy Color)</td>
        <td>&#8377;<?php echo $row['rate_item28'];?></td>
      </tr>
      <tr>
        <td>Root Touch-Inoa(Sassy Color)</td>
        <td>&#8377;<?php echo $row['rate_item29'];?></td>
      </tr>
      <tr>
        <td>Global Color(Sassy Color)</td>
        <td>&#8377;<?php echo $row['rate_item30'];?></td>
      </tr>
      <tr>
        <td>Global Highlights(Sassy Color)</td>
        <td>&#8377;<?php echo $row['rate_item31'];?></td>
      </tr>
      <tr>
        <td>Color Streaks</td>
        <td>&#8377;<?php echo $row['rate_item32'];?></td>
      </tr>
      <tr>
        <td>Straightening-Below Shoulder</td>
        <td>&#8377;<?php echo $row['rate_item33'];?></td>
      </tr>
      <tr>
        <td>Smoothening-Below Waist</td>
        <td>&#8377;<?php echo $row['rate_item34'];?></td>
     </tr>
     <tr>
       <h6> * Inclusive of all taxes and charges | for women only</h6>
     </tr>
       <?php endwhile?>

      </tbody>
      </div>
  </table>
  
</body>
</html>